Evaluation/metric-computation logic for this project currently lives
inline in the executed notebooks (`notebooks/03`, `05`, `07`) rather than
as separately importable modules. `src/models/05_model_comparison.py`
regenerates the consolidated comparison tables from the saved metrics
CSVs without retraining. This folder is a placeholder for extracting
evaluation logic into reusable functions in a later iteration.
