Feature-engineering logic for this project currently lives inline in the
executed notebooks (`notebooks/02`, `04`, `06`) rather than as separately
importable modules — the notebooks are the primary evidence for Review 2.
This folder is a placeholder for extracting that logic into reusable
functions in a later iteration.
