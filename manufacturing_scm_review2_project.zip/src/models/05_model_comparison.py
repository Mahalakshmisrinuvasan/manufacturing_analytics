"""
05_model_comparison.py
=======================
Automatically regenerates the consolidated model-comparison tables from the
metrics CSVs already saved by the notebooks (03, 05, 07). This script does
NOT retrain anything - it reads the real, previously-executed results and
assembles them into the reviewer-facing comparison tables, so the tables
can always be regenerated on demand without re-running full training.

Run with:
    python3 src/models/05_model_comparison.py
"""

import pandas as pd
import os

METRICS_DIR = "/home/claude/project/reports/metrics"
IMBALANCE_DIR = "/home/claude/project/reports/imbalance"

print("=" * 70)
print("DataCo — classification model comparison (Late_delivery_risk)")
print("=" * 70)
dataco = pd.read_csv(os.path.join(METRICS_DIR, "dataco_model_comparison.csv"), index_col="Model")
print(dataco.to_string())
best_dataco = dataco["F1"].idxmax()
print(f"\nBest by F1: {best_dataco}")

print("\n" + "=" * 70)
print("SCMS — classification model comparison (is_late)")
print("=" * 70)
scms = pd.read_csv(os.path.join(METRICS_DIR, "scms_model_comparison.csv"), index_col="Model")
print(scms.to_string())
best_scms = scms["F1"].idxmax()
print(f"\nBest baseline by F1: {best_scms}")

print("\n--- SCMS imbalance-handling comparison ---")
scms_imb = pd.read_csv(os.path.join(IMBALANCE_DIR, "scms_imbalance_method_comparison.csv"), index_col="Method")
print(scms_imb.to_string())
best_scms_imb = scms_imb["F1"].idxmax()
print(f"\nBest imbalance-handling method by F1: {best_scms_imb}")

print("\n" + "=" * 70)
print("M5 — forecasting model comparison (units_sold)")
print("=" * 70)
m5 = pd.read_csv(os.path.join(METRICS_DIR, "m5_model_comparison.csv"), index_col="Model")
print(m5.to_string())
best_m5 = m5["MAE"].idxmin()
print(f"\nBest by MAE: {best_m5}")

# ---------------------------------------------------------------------------
# Consolidated single table for the reviewer
# ---------------------------------------------------------------------------
consolidated_rows = []
for model, row in dataco.iterrows():
    consolidated_rows.append({"Dataset": "DataCo", "Model": model, **row.to_dict()})
for model, row in scms.iterrows():
    consolidated_rows.append({"Dataset": "SCMS", "Model": model, **row.to_dict()})

consolidated = pd.DataFrame(consolidated_rows)
out_path = os.path.join(METRICS_DIR, "consolidated_classification_comparison.csv")
consolidated.to_csv(out_path, index=False)
print(f"\nWrote consolidated classification comparison table: {out_path}")

print("\nSummary of BEST models selected per dataset:")
print(f" - DataCo : {best_dataco}")
print(f" - SCMS   : {best_scms_imb} (base learner: {best_scms})")
print(f" - M5     : {best_m5}")
