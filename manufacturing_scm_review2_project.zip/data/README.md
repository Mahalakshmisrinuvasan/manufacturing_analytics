# Data folder

Raw datasets are **not** committed to this repository (they exceed typical
GitHub size-friendliness and the M5 files alone total ~300+ MB).

## Required raw files

Place the following files in this folder (`data/raw/`) before running any
notebook:

| File | Source | Used by |
|---|---|---|
| `DataCoSupplyChainDataset.csv` | [DataCo Smart Supply Chain (Kaggle)](https://www.kaggle.com/datasets/shashwatwork/dataco-smart-supply-chain-for-big-data-analysis) | `01_data_audit.ipynb`, `02_dataco_feature_engineering.ipynb`, `03_dataco_model_comparison.ipynb` |
| `SCMS_Delivery_History_Dataset.csv` | [SCMS Delivery History (Kaggle / USAID)](https://www.kaggle.com/datasets/divyeshardeshana/supply-chain-shipment-pricing-data) | `01_data_audit.ipynb`, `04_scms_feature_engineering.ipynb`, `05_scms_model_comparison.ipynb` |
| `sales_train_validation.csv` | [M5 Forecasting - Accuracy (Kaggle)](https://www.kaggle.com/competitions/m5-forecasting-accuracy/data) | `01_data_audit.ipynb`, `06_m5_feature_engineering.ipynb` |
| `sell_prices.csv` | M5 Forecasting - Accuracy | `06_m5_feature_engineering.ipynb` |
| `calendar.csv` | M5 Forecasting - Accuracy | `06_m5_feature_engineering.ipynb` |

`sample_submission.csv` from the M5 competition is **not** required.

## Expected folder layout after placing files

```
data/
├── README.md              <- this file
└── raw/
    ├── DataCoSupplyChainDataset.csv
    ├── SCMS_Delivery_History_Dataset.csv
    ├── sales_train_validation.csv
    ├── sell_prices.csv
    └── calendar.csv
```

`data/processed/` is generated automatically by the feature-engineering
notebooks (`02`, `04`, `06`) and is also excluded from version control via
`.gitignore` — processed CSVs for DataCo (~21 MB) and M5 (~150 MB per file)
are regeneratable and not worth storing in Git.

## Note on file paths in the notebooks

The notebooks in this repository were developed and executed with the raw
files at `/mnt/user-data/uploads/`. When running locally, either:
1. Place the raw files in `data/raw/` and update `RAW_DIR` at the top of
   each notebook to `"../data/raw"`, or
2. Keep the notebooks pointed at wherever you've placed the files.
