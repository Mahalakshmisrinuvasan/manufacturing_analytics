# %% [markdown]
# # 02 — DataCo Feature Engineering
#
# Objective: build a leakage-free feature matrix to predict `Late_delivery_risk`
# (whether an order's delivery will be late) using only information available
# **at order time** — i.e. no post-outcome / post-shipment fields.

# %%
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import os

RAW_DIR = "/mnt/user-data/uploads"
FE_DIR = "/home/claude/project/reports/feature_engineering"
DATA_DIR = "/home/claude/project/data/processed"
os.makedirs(FE_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

pd.set_option("display.max_columns", None)

# %% [markdown]
# ## 1. Load raw data

# %%
df = pd.read_csv(os.path.join(RAW_DIR, "DataCoSupplyChainDataset.csv"), encoding="latin1")
print("Raw shape:", df.shape)
df.head(3)

# %% [markdown]
# ## 2. Clean the data
#
# - Parse the order date.
# - Drop obvious PII / free-text columns that cannot generalize as model
#   features (names, emails, passwords, street addresses, product images).
# - Drop rows where the target is missing.

# %%
df["order date (DateOrders)"] = pd.to_datetime(df["order date (DateOrders)"], errors="coerce")

pii_and_noise_cols = [
    "Customer Email", "Customer Fname", "Customer Lname", "Customer Password",
    "Customer Street", "Product Image", "Product Description", "Product Status",
    "Customer City", "Customer State", "Customer Zipcode",  # location handled via region/market instead
    "Order Zipcode",
]
df_clean = df.drop(columns=[c for c in pii_and_noise_cols if c in df.columns])
df_clean = df_clean.dropna(subset=["Late_delivery_risk"])
print("After cleaning:", df_clean.shape)

# %% [markdown]
# ## 3. LEAKAGE PREVENTION
#
# `Late_delivery_risk` is only known once a shipment has actually
# completed (or been marked late). Several columns in the raw dataset are
# only knowable **after** the delivery outcome and must NOT be used as
# predictive features, because in a real deployment they would not exist
# at prediction time (i.e. at order placement):
#
# | Excluded column | Why it leaks |
# |---|---|
# | `Days for shipping (real)` | actual shipping duration — only known after delivery |
# | `Delivery Status` | directly encodes / is derived from the same outcome as the target |
# | `Order Status` | can reflect post-outcome order state (e.g. CANCELED, SUSPECTED_FRAUD) recorded after processing |
#
# These are captured explicitly below and re-verified programmatically in
# `08_data_leakage_check.py` / `reports/data_leakage_check.md`.

# %%
LEAKAGE_COLS = ["Days for shipping (real)", "Delivery Status", "Order Status"]
print("Columns excluded due to leakage risk:", LEAKAGE_COLS)

# %% [markdown]
# ## 4. Domain-specific feature engineering
#
# Each engineered feature includes an inline comment explaining *why* it
# was created, per the project requirements.

# %%
feat = df_clean.copy()

# order_month: captures seasonality in demand / logistics load (e.g. holiday
# season congestion can increase late-delivery risk).
feat["order_month"] = feat["order date (DateOrders)"].dt.month

# order_weekday: orders placed on weekends may be processed with a delay
# before the shipping clock starts, affecting on-time performance.
feat["order_weekday"] = feat["order date (DateOrders)"].dt.dayofweek

# order_year: captures any year-over-year trend in logistics performance
# (e.g. carrier capacity changes across 2015-2018).
feat["order_year"] = feat["order date (DateOrders)"].dt.year

# is_weekend_order: binary flag; weekend order processing often differs
# structurally from weekday processing (fewer staff / carrier pickups).
feat["is_weekend_order"] = feat["order_weekday"].isin([5, 6]).astype(int)

# scheduled_shipping_duration: the number of days the carrier/company
# scheduled for delivery. This is known at order time and is one of the
# strongest legitimate predictors of late-delivery risk (tighter schedules
# are harder to hit).
feat["scheduled_shipping_duration"] = feat["Days for shipment (scheduled)"]

# order_item_quantity / order_value: larger or higher-value orders can
# require more picking/packing time or special handling, which can affect
# on-time performance.
feat["order_item_quantity"] = feat["Order Item Quantity"]
feat["order_value"] = feat["Order Item Total"]

# discount_rate: heavily discounted promotional orders often surge in
# volume around the same time, straining fulfillment capacity.
feat["discount_rate"] = feat["Order Item Discount Rate"]

# unit_price: a proxy for product handling complexity/value (e.g. high-value
# items sometimes need extra verification/security steps at dispatch).
feat["unit_price"] = feat["Order Item Product Price"]

# shipping_mode: categorical - different carriers/modes (Standard Class,
# First Class, Same Day, Second Class) have structurally different
# on-time performance.
feat["shipping_mode"] = feat["Shipping Mode"]

# market / order_region: geographic features - some regions/markets have
# systematically longer or less reliable logistics networks.
feat["market"] = feat["Market"]
feat["order_region"] = feat["Order Region"]

# category_name / department_name: product category can affect handling
# requirements (e.g. fragile goods, cold-chain) and therefore delay risk.
feat["category_name"] = feat["Category Name"]
feat["department_name"] = feat["Department Name"]

# customer_segment: business/consumer/home-office customers may be routed
# through different fulfillment SLAs.
feat["customer_segment"] = feat["Customer Segment"]

# schedule_tightness_flag: an interaction feature - flags orders scheduled
# for very fast delivery (<=1 day), which are inherently higher risk of
# missing the promised date regardless of other factors.
feat["schedule_tightness_flag"] = (feat["scheduled_shipping_duration"] <= 1).astype(int)

FEATURE_COLS = [
    "order_month", "order_weekday", "order_year", "is_weekend_order",
    "scheduled_shipping_duration", "order_item_quantity", "order_value",
    "discount_rate", "unit_price", "shipping_mode", "market", "order_region",
    "category_name", "department_name", "customer_segment",
    "schedule_tightness_flag",
]
TARGET_COL = "Late_delivery_risk"

print("Final engineered feature columns:")
for c in FEATURE_COLS:
    print(" -", c)

# %% [markdown]
# ## 5. Sanity-check: confirm no leakage columns made it into the final matrix

# %%
leak_found = [c for c in LEAKAGE_COLS if c in FEATURE_COLS]
assert len(leak_found) == 0, f"Leakage columns present in features: {leak_found}"
print("PASS: no leakage columns present in FEATURE_COLS.")

# %% [markdown]
# ## 6. Save processed feature matrix

# %%
model_df = feat[FEATURE_COLS + [TARGET_COL]].dropna()
print("Modeling matrix shape after dropping remaining NaNs:", model_df.shape)
model_df.to_csv(os.path.join(DATA_DIR, "dataco_features.csv"), index=False)
print("Saved:", os.path.join(DATA_DIR, "dataco_features.csv"))

# %% [markdown]
# ## 7. Feature-engineering summary table (before -> after)

# %%
summary_rows = [
    ("Days for shipment (scheduled)", "scheduled_shipping_duration", "Renamed for clarity; strongest legitimate leading indicator of delay risk."),
    ("order date (DateOrders)", "order_month, order_weekday, order_year, is_weekend_order", "Decomposed timestamp into seasonality/weekday signals known at order time."),
    ("Order Item Quantity", "order_item_quantity", "Kept as-is; larger orders can affect fulfillment time."),
    ("Order Item Total", "order_value", "Renamed; higher-value orders may need extra handling/verification."),
    ("Order Item Discount Rate", "discount_rate", "Kept; promo-driven demand spikes can strain fulfillment."),
    ("Order Item Product Price", "unit_price", "Kept; proxy for handling complexity."),
    ("Shipping Mode", "shipping_mode", "Kept; carriers/modes differ structurally in reliability."),
    ("Market / Order Region", "market, order_region", "Kept; geographic logistics network reliability varies."),
    ("Category Name / Department Name", "category_name, department_name", "Kept; product type affects handling requirements."),
    ("Customer Segment", "customer_segment", "Kept; different fulfillment SLAs by segment."),
    ("(derived)", "schedule_tightness_flag", "New interaction feature flagging very tight (<=1 day) schedules."),
    ("Days for shipping (real)", "EXCLUDED (leakage)", "Only known after delivery completes."),
    ("Delivery Status", "EXCLUDED (leakage)", "Encodes the same outcome as the target."),
    ("Order Status", "EXCLUDED (leakage)", "Can reflect post-processing order state."),
]
fe_table = pd.DataFrame(summary_rows, columns=["Original Feature", "Engineered Feature", "Reason"])
fe_table.insert(0, "Dataset", "DataCo")
fe_table.to_csv(os.path.join(FE_DIR, "dataco_feature_table.csv"), index=False)
fe_table

# %% [markdown]
# ## 8. Quick exploratory plots on engineered features

# %%
plt.figure(figsize=(6, 4))
model_df.groupby("shipping_mode")[TARGET_COL].mean().sort_values().plot(kind="barh", color="#4C72B0")
plt.xlabel("Late delivery rate")
plt.title("DataCo: Late-delivery rate by shipping mode")
plt.tight_layout()
plt.savefig(os.path.join(FE_DIR, "dataco_late_rate_by_shipping_mode.png"), dpi=120)
plt.close()

plt.figure(figsize=(6, 4))
model_df.groupby("scheduled_shipping_duration")[TARGET_COL].mean().plot(kind="bar", color="#55A868")
plt.xlabel("Scheduled shipping duration (days)")
plt.ylabel("Late delivery rate")
plt.title("DataCo: Late-delivery rate vs scheduled shipping duration")
plt.tight_layout()
plt.savefig(os.path.join(FE_DIR, "dataco_late_rate_by_schedule.png"), dpi=120)
plt.close()

print("Saved feature-engineering plots to:", FE_DIR)

# %% [markdown]
# ## 9. Final feature list (for reproducibility evidence)

# %%
with open(os.path.join(FE_DIR, "dataco_final_feature_list.txt"), "w") as f:
    f.write("Target: " + TARGET_COL + "\n\n")
    f.write("Final model features:\n")
    for c in FEATURE_COLS:
        f.write(f" - {c}\n")
    f.write("\nExcluded (leakage) columns:\n")
    for c in LEAKAGE_COLS:
        f.write(f" - {c}\n")

print("Wrote final feature list.")
print("\nDataCo feature engineering complete.")
