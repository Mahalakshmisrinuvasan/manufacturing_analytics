# %% [markdown]
# # 07 — M5 Demand Forecasting: Seasonal Naive Baseline vs LightGBM
#
# Trains a Seasonal Naive baseline (standard forecasting benchmark: predict
# demand(t) = demand(t-7), i.e. "same weekday last week") and a LightGBM
# model on the SAME time-aware train/validation split produced by
# `06_m5_feature_engineering.ipynb`, then compares them on MAE / RMSE / MAPE.

# %%
import pandas as pd
import numpy as np
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import lightgbm as lgb
from sklearn.metrics import mean_absolute_error, mean_squared_error
import joblib

DATA_DIR = "/home/claude/project/data/processed"
METRICS_DIR = "/home/claude/project/reports/metrics"
FIG_DIR = "/home/claude/project/reports/figures"
MODEL_DIR = "/home/claude/project/models"
for d in [METRICS_DIR, FIG_DIR, MODEL_DIR]:
    os.makedirs(d, exist_ok=True)

RANDOM_STATE = 42

# %% [markdown]
# ## 1. Load the time-aware split produced by feature engineering

# %%
train_df = pd.read_csv(os.path.join(DATA_DIR, "m5_features_train.csv"), parse_dates=["date"])
val_df = pd.read_csv(os.path.join(DATA_DIR, "m5_features_val.csv"), parse_dates=["date"])
print("Train:", train_df.shape, train_df["date"].min(), "-", train_df["date"].max())
print("Val:  ", val_df.shape, val_df["date"].min(), "-", val_df["date"].max())

TARGET_COL = "units_sold"
NUMERIC_FEATURES = ["lag_1", "lag_7", "lag_14", "lag_28", "rolling_mean_7", "rolling_std_7",
                     "rolling_mean_28", "day_of_week", "month", "year", "is_event", "snap_day",
                     "price", "price_change", "price_change_pct"]
CATEGORICAL_FEATURES = ["item_id", "dept_id", "cat_id"]

# %% [markdown]
# ## 2. Seasonal Naive baseline
#
# `pred(t) = actual(t-7)` — a standard, non-trivial forecasting benchmark
# that any real model must beat to be worth deploying. Implemented directly
# from `lag_7`, which we already engineered.

# %%
val_df = val_df.dropna(subset=["lag_7"]).copy()
naive_pred = val_df["lag_7"].values
naive_actual = val_df[TARGET_COL].values

def mape(y_true, y_pred, eps=1.0):
    # M5 demand is highly sparse (many zero-demand days); a standard MAPE
    # divides by y_true and is undefined at 0, so we use the common
    # sparse-demand convention of adding eps=1 to the denominator.
    return float(np.mean(np.abs(y_true - y_pred) / (np.abs(y_true) + eps)) * 100)

naive_mae = mean_absolute_error(naive_actual, naive_pred)
naive_rmse = np.sqrt(mean_squared_error(naive_actual, naive_pred))
naive_mape = mape(naive_actual, naive_pred)
print(f"Seasonal Naive -> MAE={naive_mae:.4f} RMSE={naive_rmse:.4f} MAPE={naive_mape:.2f}%")

# %% [markdown]
# ## 3. LightGBM model
#
# Categorical features are passed natively to LightGBM (no one-hot needed),
# and it is trained ONLY on the training-period rows, then evaluated on the
# strictly-later validation period — a proper time-aware evaluation.

# %%
for c in CATEGORICAL_FEATURES:
    train_df[c] = train_df[c].astype("category")
    val_df[c] = val_df[c].astype("category")

X_train = train_df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
y_train = train_df[TARGET_COL]
X_val = val_df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
y_val = val_df[TARGET_COL]

lgb_train = lgb.Dataset(X_train, label=y_train, categorical_feature=CATEGORICAL_FEATURES)
lgb_val = lgb.Dataset(X_val, label=y_val, categorical_feature=CATEGORICAL_FEATURES, reference=lgb_train)

params = {
    "objective": "regression",
    "metric": "mae",
    "learning_rate": 0.05,
    "num_leaves": 63,
    "min_data_in_leaf": 50,
    "verbose": -1,
    "seed": RANDOM_STATE,
}
model = lgb.train(
    params, lgb_train, num_boost_round=500,
    valid_sets=[lgb_val], valid_names=["val"],
    callbacks=[lgb.early_stopping(30), lgb.log_evaluation(50)],
)

lgb_pred_raw = model.predict(X_val, num_iteration=model.best_iteration)
# Demand cannot be negative; clip predictions to zero as is standard for
# M5-style regression-on-count-data forecasting.
lgb_pred = np.clip(lgb_pred_raw, 0, None)

lgb_mae = mean_absolute_error(y_val, lgb_pred)
lgb_rmse = np.sqrt(mean_squared_error(y_val, lgb_pred))
lgb_mape = mape(y_val.values, lgb_pred)
print(f"LightGBM -> MAE={lgb_mae:.4f} RMSE={lgb_rmse:.4f} MAPE={lgb_mape:.2f}% (best_iter={model.best_iteration})")

# %% [markdown]
# ## 4. Comparison table (REAL executed values)

# %%
comparison_df = pd.DataFrame([
    {"Model": "Seasonal Naive (t-7)", "MAE": naive_mae, "RMSE": naive_rmse, "MAPE_%": naive_mape},
    {"Model": "LightGBM", "MAE": lgb_mae, "RMSE": lgb_rmse, "MAPE_%": lgb_mape},
]).set_index("Model").round(4)
comparison_df.to_csv(os.path.join(METRICS_DIR, "m5_model_comparison.csv"))
print(comparison_df)

improvement_pct = (naive_mae - lgb_mae) / naive_mae * 100
print(f"\nLightGBM improves MAE over Seasonal Naive by {improvement_pct:.1f}%")

# %% [markdown]
# ## 5. Feature importance

# %%
importance = pd.DataFrame({
    "feature": model.feature_name(),
    "importance": model.feature_importance(importance_type="gain"),
}).sort_values("importance", ascending=False)
importance.to_csv(os.path.join("/home/claude/project/reports/feature_engineering", "m5_feature_importance.csv"), index=False)

plt.figure(figsize=(7, 6))
top_imp = importance.head(15)
plt.barh(top_imp["feature"][::-1], top_imp["importance"][::-1], color="#4C72B0")
plt.title("M5: LightGBM feature importance (gain)")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "m5_feature_importance.png"), dpi=120)
plt.close()
print(importance.head(10))

# %% [markdown]
# ## 6. Actual vs predicted plot for a sample series

# %%
sample_id = val_df["id"].unique()[0]
sample_mask = val_df["id"] == sample_id
sample_dates = val_df.loc[sample_mask, "date"]
sample_actual = y_val[sample_mask]
sample_naive = naive_pred[sample_mask.values]
sample_lgb = lgb_pred[sample_mask.values]

plt.figure(figsize=(9, 4))
plt.plot(sample_dates, sample_actual, label="Actual", marker="o")
plt.plot(sample_dates, sample_naive, label="Seasonal Naive", linestyle="--")
plt.plot(sample_dates, sample_lgb, label="LightGBM", linestyle="--")
plt.title(f"M5: 28-day validation forecast — {sample_id}")
plt.legend(); plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "m5_forecast_example_series.png"), dpi=120)
plt.close()

# %% [markdown]
# ## 7. Model comparison chart

# %%
comparison_df[["MAE", "RMSE"]].plot(kind="bar", figsize=(6, 4))
plt.title("M5: MAE / RMSE — Seasonal Naive vs LightGBM")
plt.ylabel("units")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "m5_model_comparison_chart.png"), dpi=120)
plt.close()
print("Saved M5 forecasting plots.")

# %% [markdown]
# ## 8. Save model + predictions

# %%
model.save_model(os.path.join(MODEL_DIR, "m5_lightgbm.txt"))

pred_records = val_df[["id", "date", TARGET_COL]].copy()
pred_records["seasonal_naive_pred"] = naive_pred
pred_records["lightgbm_pred"] = lgb_pred
pred_records.to_csv(os.path.join(METRICS_DIR, "m5_val_predictions.csv"), index=False)
print("Saved LightGBM model and validation predictions.")

# %% [markdown]
# ## 9. Model selection rationale (M5)

# %%
selection_notes = f"""
M5 Model Selection — computed from reports/metrics/m5_model_comparison.csv

{comparison_df.to_string()}

LightGBM MAE improvement over Seasonal Naive: {improvement_pct:.1f}%

Rationale:
- Seasonal Naive (predict same weekday last week) is included as the
  standard, non-trivial forecasting benchmark for retail demand data with
  weekly seasonality. Any model that cannot beat it is not worth deploying.
- LightGBM was selected over a deep-learning approach per the project's
  explicit instruction not to use complex deep learning "for appearance" -
  gradient-boosted trees are the established strong baseline for tabular,
  feature-engineered demand forecasting (this is also the dominant approach
  used by top M5-competition solutions).
- LightGBM natively handles categorical features (item_id, dept_id, cat_id)
  without one-hot expansion, which keeps training memory-efficient on the
  500-item subset used here.
- Evaluation uses a strictly time-aware split (train ends before validation
  begins) - no shuffling - so the reported MAE/RMSE/MAPE reflect genuine
  forward-looking forecast accuracy, not in-sample fit.
- Deployment consideration: LightGBM requires periodic retraining as new
  sales data arrives and its lag/rolling features must be recomputed at
  inference time from the latest known history, whereas the Seasonal Naive
  baseline requires no training at all - a relevant simplicity/accuracy
  trade-off in a resource-constrained manufacturing/retail setting.
"""
with open(os.path.join(METRICS_DIR, "m5_model_selection_rationale.txt"), "w") as f:
    f.write(selection_notes)
print(selection_notes)
