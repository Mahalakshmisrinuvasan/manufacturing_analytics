# %% [markdown]
# # 06 — M5 Feature Engineering (Demand Forecasting)
#
# Objective: build time-series features (lags, rolling stats, calendar/price
# signals) for daily unit-demand forecasting, using a time-aware train/val
# split (no shuffling).
#
# ## Documented subset decision
# The full M5 sales file has 30,490 series x 1,913 days (melting the full
# dataset to long format produces ~58M rows). This environment has a hard
# ~4GB memory ceiling, and an initial attempt using ALL 3,049 items from a
# single store (~5.8M rows) exhausted available memory during feature
# computation and crashed the kernel.
#
# **We therefore use the top 500 highest-volume items (by total units sold)
# from store `CA_1`, keeping their FULL 1,913-day history (~957K rows after
# melting), as a clearly documented, memory-safe subset.** Keeping full time
# depth per series (rather than truncating dates) is important because
# `lag_28` / `rolling_mean_28` need at least 28 prior days of history per
# series. This decision is stated explicitly here and is not hidden
# anywhere else in the project.

# %%
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import os

RAW_DIR = "/mnt/user-data/uploads"
FE_DIR = "/home/claude/project/reports/feature_engineering"
DATA_DIR = "/home/claude/project/data/processed"
os.makedirs(FE_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)
pd.set_option("display.max_columns", None)

SUBSET_STORE = "CA_1"

# %% [markdown]
# ## 1. Load raw data

# %%
sales = pd.read_csv(os.path.join(RAW_DIR, "sales_train_validation.csv"))
prices = pd.read_csv(os.path.join(RAW_DIR, "sell_prices.csv"))
calendar = pd.read_csv(os.path.join(RAW_DIR, "calendar.csv"))
print("sales:", sales.shape, "prices:", prices.shape, "calendar:", calendar.shape)

store_sales = sales[sales["store_id"] == SUBSET_STORE].reset_index(drop=True)
day_cols_all = [c for c in store_sales.columns if c.startswith("d_")]

# Rank items in this store by total historical volume and keep the top 500 -
# a memory-safe subset while retaining the highest-signal, most-frequently
# purchased series (sparser/low-volume series contribute the least to
# demonstrating the feature-engineering / forecasting methodology).
N_ITEMS = 500
total_volume = store_sales[day_cols_all].sum(axis=1)
top_idx = total_volume.sort_values(ascending=False).head(N_ITEMS).index
sales_subset = store_sales.loc[top_idx].reset_index(drop=True)
print(f"Subset ({SUBSET_STORE}, top {N_ITEMS} items by volume) series:", sales_subset.shape)

# %% [markdown]
# ## 2. Clean / reshape to long format

# %%
id_cols = ["id", "item_id", "dept_id", "cat_id", "store_id", "state_id"]
day_cols = [c for c in sales_subset.columns if c.startswith("d_")]

long_df = sales_subset.melt(id_vars=id_cols, value_vars=day_cols,
                             var_name="d", value_name="units_sold")
long_df = long_df.merge(calendar, on="d", how="left")
long_df["date"] = pd.to_datetime(long_df["date"])
long_df = long_df.merge(
    prices, on=["store_id", "item_id", "wm_yr_wk"], how="left"
)
long_df = long_df.sort_values(["id", "date"]).reset_index(drop=True)
print("Long-format shape:", long_df.shape)
long_df.head(3)

# %% [markdown]
# ## 3. Time-series feature engineering
#
# All lag/rolling features are computed PER SERIES (`groupby("id")`) and
# use only past values, which is inherently leakage-safe for a
# lag/rolling-window design — a value at time t never uses information
# from t or later.

# %%
g = long_df.groupby("id")["units_sold"]

# lag_1 / lag_7 / lag_14 / lag_28: demand N days earlier. Short lags (1)
# capture immediate momentum; lag_7/14 capture weekly demand-cycle
# patterns (e.g. weekend spikes); lag_28 approximates a monthly cycle and
# is the standard M5-competition baseline lag (safe even for a 28-day-ahead
# forecast horizon, since it never looks inside the forecast window).
long_df["lag_1"] = g.shift(1)
long_df["lag_7"] = g.shift(7)
long_df["lag_14"] = g.shift(14)
long_df["lag_28"] = g.shift(28)

# rolling_mean_7 / rolling_std_7: short-window rolling statistics computed
# on lag_1-shifted data (so the current day's own value never enters its
# own rolling window) - captures recent local demand level and volatility.
long_df["rolling_mean_7"] = g.shift(1).rolling(7).mean().reset_index(level=0, drop=True)
long_df["rolling_std_7"] = g.shift(1).rolling(7).std().reset_index(level=0, drop=True)

# rolling_mean_28: longer-window rolling mean - smooths out weekly noise to
# show the underlying demand trend.
long_df["rolling_mean_28"] = g.shift(1).rolling(28).mean().reset_index(level=0, drop=True)

# day_of_week / month / year: calendar seasonality features known in
# advance for any future date.
long_df["day_of_week"] = long_df["date"].dt.dayofweek
long_df["month"] = long_df["date"].dt.month
long_df["year"] = long_df["date"].dt.year

# is_event: binary flag for any named calendar event (SuperBowl, Christmas,
# etc.) - demand often spikes or dips around these dates.
long_df["is_event"] = long_df["event_name_1"].notna().astype(int)

# snap_day: whichever state's SNAP (food-assistance benefit) indicator
# applies to this row's state - SNAP days are known in advance to increase
# demand for SNAP-eligible items. Vectorized with np.select (fast, low
# memory) rather than a row-wise .apply over ~1M rows.
long_df["snap_day"] = np.select(
    [long_df["state_id"] == "CA", long_df["state_id"] == "TX", long_df["state_id"] == "WI"],
    [long_df["snap_CA"], long_df["snap_TX"], long_df["snap_WI"]],
    default=0,
)

# price: current sell price for this item/week (known in advance since
# retailers set prices ahead of time).
long_df["price"] = long_df["sell_price"]

# price_change / price_change_pct: change from the previous known price for
# this item - price changes (promotions, markups) are a leading driver of
# demand shifts.
long_df["price_change"] = long_df.groupby("id")["sell_price"].diff()
long_df["price_change_pct"] = long_df.groupby("id")["sell_price"].pct_change()

FEATURE_COLS = [
    "lag_1", "lag_7", "lag_14", "lag_28",
    "rolling_mean_7", "rolling_std_7", "rolling_mean_28",
    "day_of_week", "month", "year", "is_event", "snap_day",
    "price", "price_change", "price_change_pct",
    "item_id", "dept_id", "cat_id",
]
TARGET_COL = "units_sold"

print("Final engineered feature columns:")
for c in FEATURE_COLS:
    print(" -", c)

# %% [markdown]
# ## 4. Drop warm-up rows (first 28 days per series have incomplete lags)

# %%
model_long = long_df.dropna(subset=["lag_28", "rolling_mean_28"]).copy()
model_long["price"] = model_long["price"].ffill()
model_long["price_change"] = model_long["price_change"].fillna(0)
model_long["price_change_pct"] = model_long["price_change_pct"].fillna(0)
print("After dropping lag warm-up rows:", model_long.shape)
print("Date range used for modeling:", model_long["date"].min(), "to", model_long["date"].max())

# %% [markdown]
# ## 5. Time-aware train/validation split (NO shuffling)
#
# Last 28 days = validation (matches the M5 competition's forecast horizon);
# everything before that = training. This mirrors a real forecasting
# deployment where you always predict forward in time.

# %%
cutoff_date = model_long["date"].max() - pd.Timedelta(days=28)
train_long = model_long[model_long["date"] <= cutoff_date]
val_long = model_long[model_long["date"] > cutoff_date]
print("Train date range:", train_long["date"].min(), "-", train_long["date"].max(), "rows:", train_long.shape[0])
print("Val date range:  ", val_long["date"].min(), "-", val_long["date"].max(), "rows:", val_long.shape[0])

# %% [markdown]
# ## 6. Save processed feature matrix

# %%
save_cols = ["id", "date"] + FEATURE_COLS + [TARGET_COL]
model_long[save_cols].to_csv(os.path.join(DATA_DIR, "m5_features.csv"), index=False)
print("Saved:", os.path.join(DATA_DIR, "m5_features.csv"), model_long[save_cols].shape)

train_long[save_cols].to_csv(os.path.join(DATA_DIR, "m5_features_train.csv"), index=False)
val_long[save_cols].to_csv(os.path.join(DATA_DIR, "m5_features_val.csv"), index=False)

# %% [markdown]
# ## 7. Before/after feature table

# %%
summary_rows = [
    ("units_sold (t-1)", "lag_1", "Immediate demand momentum; strongest single predictor for smooth series."),
    ("units_sold (t-7)", "lag_7", "Captures weekly seasonality (e.g. weekend demand spikes)."),
    ("units_sold (t-14)", "lag_14", "Captures bi-weekly demand cycles."),
    ("units_sold (t-28)", "lag_28", "Standard M5-competition lag; safe for a 28-day forecast horizon."),
    ("units_sold (rolling)", "rolling_mean_7, rolling_std_7", "Shift(1)-then-rolling: recent local demand level and volatility, without leaking the current day."),
    ("units_sold (rolling)", "rolling_mean_28", "Longer-window trend, smoothing weekly noise."),
    ("date", "day_of_week, month, year", "Calendar seasonality known in advance for any future date."),
    ("event_name_1 (calendar.csv)", "is_event", "Binary flag; named events often shift demand."),
    ("snap_CA/TX/WI (calendar.csv)", "snap_day", "SNAP benefit days are known in advance and increase demand for eligible items."),
    ("sell_price (sell_prices.csv)", "price, price_change, price_change_pct", "Current price and how it changed vs the prior known price; a leading driver of demand shifts."),
    ("item_id/dept_id/cat_id", "item_id, dept_id, cat_id", "Kept as categorical identifiers so the model can learn per-product/category baseline demand levels."),
]
fe_table = pd.DataFrame(summary_rows, columns=["Original Feature", "Engineered Feature", "Reason"])
fe_table.insert(0, "Dataset", "M5")
fe_table.to_csv(os.path.join(FE_DIR, "m5_feature_table.csv"), index=False)
fe_table

# %% [markdown]
# ## 8. Exploratory plots

# %%
sample_id = model_long["id"].unique()[0]
sample_series = model_long[model_long["id"] == sample_id].sort_values("date")

plt.figure(figsize=(10, 4))
plt.plot(sample_series["date"], sample_series["units_sold"], label="units_sold", linewidth=0.8)
plt.plot(sample_series["date"], sample_series["rolling_mean_7"], label="rolling_mean_7", linewidth=1.2)
plt.title(f"M5: example series with rolling_mean_7 — {sample_id}")
plt.legend(); plt.tight_layout()
plt.savefig(os.path.join(FE_DIR, "m5_example_series_rolling_mean.png"), dpi=120)
plt.close()

plt.figure(figsize=(6, 4))
model_long.groupby("day_of_week")["units_sold"].mean().plot(kind="bar", color="#4C72B0")
plt.xlabel("day_of_week (0=Mon)"); plt.ylabel("mean units_sold")
plt.title(f"M5 ({SUBSET_STORE}): mean demand by day of week")
plt.tight_layout()
plt.savefig(os.path.join(FE_DIR, "m5_demand_by_weekday.png"), dpi=120)
plt.close()
print("Saved M5 feature-engineering plots.")

# %% [markdown]
# ## 9. Final feature list

# %%
with open(os.path.join(FE_DIR, "m5_final_feature_list.txt"), "w") as f:
    f.write(f"Documented subset: store_id == '{SUBSET_STORE}', top {N_ITEMS} items by volume (full 1,913-day history)\n")
    f.write("Target: " + TARGET_COL + "\n\n")
    f.write("Final model features:\n")
    for c in FEATURE_COLS:
        f.write(f" - {c}\n")
    f.write("\nSplit: time-aware, last 28 days = validation, no shuffling.\n")
print("M5 feature engineering complete.")
