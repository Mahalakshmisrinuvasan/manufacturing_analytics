"""
01_data_audit.py
=================
Part 1 of the Manufacturing Supply Chain Analytics project.

Performs a REAL data audit (no manually typed statistics) on all three
source datasets:
    1. DataCo Supply Chain Dataset      -> Delivery Risk Prediction
    2. SCMS Delivery History Dataset    -> Supplier/Shipment Risk Prediction
    3. M5 (sales_train_validation.csv + sell_prices.csv + calendar.csv)
                                         -> Demand Forecasting

All numbers below are computed directly from the uploaded CSV files.
Outputs (CSV tables + PNG plots) are written to reports/data_audit/.
"""

import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RAW_DIR = "/mnt/user-data/uploads"
OUT_DIR = "/home/claude/project/reports/data_audit"
os.makedirs(OUT_DIR, exist_ok=True)

pd.set_option("display.max_columns", None)


def audit_dataframe(df: pd.DataFrame, name: str) -> dict:
    """Compute the standard audit block for a single dataframe."""
    n_rows, n_cols = df.shape

    dtypes = df.dtypes.astype(str)

    missing_count = df.isna().sum()
    missing_pct = (missing_count / n_rows * 100).round(2)

    duplicate_rows = int(df.duplicated().sum())

    # unique value counts per column
    nunique = df.nunique(dropna=True)

    # column-level summary table
    col_summary = pd.DataFrame({
        "column": df.columns,
        "dtype": dtypes.values,
        "missing_count": missing_count.values,
        "missing_pct": missing_pct.values,
        "n_unique": nunique.reindex(df.columns).values,
    })
    col_summary.to_csv(os.path.join(OUT_DIR, f"{name}_column_summary.csv"), index=False)

    # numerical statistics (describe)
    num_df = df.select_dtypes(include=[np.number])
    if num_df.shape[1] > 0:
        num_stats = num_df.describe().T
        num_stats.to_csv(os.path.join(OUT_DIR, f"{name}_numerical_statistics.csv"))
    else:
        num_stats = pd.DataFrame()

    summary = {
        "dataset": name,
        "n_rows": n_rows,
        "n_cols": n_cols,
        "duplicate_rows": duplicate_rows,
        "total_missing_cells": int(missing_count.sum()),
        "pct_missing_overall": round(missing_count.sum() / (n_rows * n_cols) * 100, 3),
        "n_numeric_cols": num_df.shape[1],
        "n_categorical_cols": n_cols - num_df.shape[1],
    }
    return summary


# ---------------------------------------------------------------------------
# 1. DataCo Supply Chain Dataset
# ---------------------------------------------------------------------------
print("Loading DataCoSupplyChainDataset.csv ...")
dataco = pd.read_csv(os.path.join(RAW_DIR, "DataCoSupplyChainDataset.csv"), encoding="latin1")
dataco_summary = audit_dataframe(dataco, "dataco")

# order date range
dataco["order date (DateOrders)"] = pd.to_datetime(dataco["order date (DateOrders)"], errors="coerce")
dataco_summary["date_min"] = str(dataco["order date (DateOrders)"].min())
dataco_summary["date_max"] = str(dataco["order date (DateOrders)"].max())

# target candidate: Late_delivery_risk
target_dist = dataco["Late_delivery_risk"].value_counts().sort_index()
target_dist.to_csv(os.path.join(OUT_DIR, "dataco_target_distribution.csv"))
dataco_summary["target_col"] = "Late_delivery_risk"
dataco_summary["target_class_0"] = int(target_dist.get(0, 0))
dataco_summary["target_class_1"] = int(target_dist.get(1, 0))
dataco_summary["target_imbalance_ratio"] = round(
    max(target_dist) / min(target_dist), 3
) if target_dist.min() > 0 else None

# plot target distribution
plt.figure(figsize=(5, 4))
target_dist.plot(kind="bar", color=["#4C72B0", "#DD8452"])
plt.title("DataCo: Late_delivery_risk distribution")
plt.xlabel("Late_delivery_risk")
plt.ylabel("count")
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "dataco_target_distribution.png"), dpi=120)
plt.close()

# Delivery Status breakdown (related categorical target)
delivery_status_dist = dataco["Delivery Status"].value_counts()
delivery_status_dist.to_csv(os.path.join(OUT_DIR, "dataco_delivery_status_distribution.csv"))

print("DataCo audit complete:", dataco_summary)


# ---------------------------------------------------------------------------
# 2. SCMS Delivery History Dataset
# ---------------------------------------------------------------------------
print("\nLoading SCMS_Delivery_History_Dataset.csv ...")
scms = pd.read_csv(os.path.join(RAW_DIR, "SCMS_Delivery_History_Dataset.csv"), encoding="utf-8-sig")
scms_summary = audit_dataframe(scms, "scms")

date_cols = ["PQ First Sent to Client Date", "PO Sent to Vendor Date",
             "Scheduled Delivery Date", "Delivered to Client Date", "Delivery Recorded Date"]
for c in date_cols:
    scms[c + "_parsed"] = pd.to_datetime(scms[c], errors="coerce")

scms_summary["scheduled_delivery_date_min"] = str(scms["Scheduled Delivery Date_parsed"].min())
scms_summary["scheduled_delivery_date_max"] = str(scms["Scheduled Delivery Date_parsed"].max())
scms_summary["delivered_to_client_date_min"] = str(scms["Delivered to Client Date_parsed"].min())
scms_summary["delivered_to_client_date_max"] = str(scms["Delivered to Client Date_parsed"].max())

# unparseable-date counts (SCMS is known to contain placeholder strings like 'Date Not Captured')
unparsed_counts = {c: int(scms[c + "_parsed"].isna().sum() - scms[c].isna().sum())
                    for c in date_cols}
pd.Series(unparsed_counts, name="unparseable_non_null_dates").to_csv(
    os.path.join(OUT_DIR, "scms_unparseable_dates.csv"))

# candidate target: delivery delay in days
scms["delay_days"] = (scms["Delivered to Client Date_parsed"] - scms["Scheduled Delivery Date_parsed"]).dt.days
delay_valid = scms["delay_days"].dropna()
scms_summary["delay_days_available_rows"] = int(delay_valid.shape[0])
scms_summary["delay_days_mean"] = round(float(delay_valid.mean()), 3) if len(delay_valid) else None
scms_summary["delay_days_median"] = float(delay_valid.median()) if len(delay_valid) else None

late_flag = (delay_valid > 0).astype(int)
late_dist = late_flag.value_counts().sort_index()
late_dist.to_csv(os.path.join(OUT_DIR, "scms_target_distribution.csv"))
scms_summary["target_class_0_ontime"] = int(late_dist.get(0, 0))
scms_summary["target_class_1_late"] = int(late_dist.get(1, 0))
scms_summary["target_imbalance_ratio"] = round(
    max(late_dist) / min(late_dist), 3) if late_dist.min() > 0 else None

plt.figure(figsize=(5, 4))
late_dist.plot(kind="bar", color=["#4C72B0", "#DD8452"])
plt.title("SCMS: Late-delivery target distribution")
plt.xlabel("late (1) vs on-time/early (0)")
plt.ylabel("count")
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "scms_target_distribution.png"), dpi=120)
plt.close()

plt.figure(figsize=(6, 4))
delay_valid.clip(-30, 60).hist(bins=60, color="#55A868")
plt.title("SCMS: Distribution of delivery delay (days), clipped [-30, 60]")
plt.xlabel("delay_days (Delivered - Scheduled)")
plt.ylabel("count")
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "scms_delay_days_hist.png"), dpi=120)
plt.close()

print("SCMS audit complete:", scms_summary)


# ---------------------------------------------------------------------------
# 3. M5 Forecasting dataset (sales + prices + calendar)
# ---------------------------------------------------------------------------
print("\nLoading M5 files (sales_train_validation.csv, sell_prices.csv, calendar.csv) ...")
sales = pd.read_csv(os.path.join(RAW_DIR, "sales_train_validation.csv"))
prices = pd.read_csv(os.path.join(RAW_DIR, "sell_prices.csv"))
calendar = pd.read_csv(os.path.join(RAW_DIR, "calendar.csv"))

m5_summary = {
    "sales_n_rows": sales.shape[0],
    "sales_n_cols": sales.shape[1],
    "sales_n_series": sales.shape[0],
    "sales_n_day_columns": len([c for c in sales.columns if c.startswith("d_")]),
    "sales_duplicate_rows": int(sales.duplicated().sum()),
    "sales_missing_cells": int(sales.isna().sum().sum()),
    "prices_n_rows": prices.shape[0],
    "prices_n_cols": prices.shape[1],
    "prices_missing_cells": int(prices.isna().sum().sum()),
    "prices_duplicate_rows": int(prices.duplicated().sum()),
    "calendar_n_rows": calendar.shape[0],
    "calendar_n_cols": calendar.shape[1],
    "calendar_date_min": str(calendar["date"].min()),
    "calendar_date_max": str(calendar["date"].max()),
}

# store / state / category breakdown
m5_summary["n_stores"] = int(sales["store_id"].nunique())
m5_summary["n_states"] = int(sales["state_id"].nunique())
m5_summary["n_categories"] = int(sales["cat_id"].nunique())
m5_summary["n_departments"] = int(sales["dept_id"].nunique())
m5_summary["n_items"] = int(sales["item_id"].nunique())

sales["cat_id"].value_counts().to_csv(os.path.join(OUT_DIR, "m5_category_counts.csv"))
sales["state_id"].value_counts().to_csv(os.path.join(OUT_DIR, "m5_state_counts.csv"))

# demand distribution: total units sold per day across all series (sample stat)
day_cols = [c for c in sales.columns if c.startswith("d_")]
total_daily_demand = sales[day_cols].sum(axis=0)
total_daily_demand.index.name = "d"
total_daily_demand.name = "total_units_sold"
total_daily_demand.to_csv(os.path.join(OUT_DIR, "m5_total_daily_demand.csv"))

plt.figure(figsize=(10, 4))
plt.plot(range(len(total_daily_demand)), total_daily_demand.values, linewidth=0.8, color="#4C72B0")
plt.title("M5: Total units sold per day, across all 30,490 series (d_1..d_%d)" % len(day_cols))
plt.xlabel("day index")
plt.ylabel("total units sold")
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "m5_total_daily_demand.png"), dpi=120)
plt.close()

# per-series stats: mean, zero-rate (sparsity is a key characteristic of M5)
sample_matrix = sales[day_cols].values
zero_rate = (sample_matrix == 0).mean()
m5_summary["overall_zero_demand_rate"] = round(float(zero_rate), 4)
m5_summary["mean_daily_units_per_series"] = round(float(sample_matrix.mean()), 4)

# prices numeric stats
prices["sell_price"].describe().to_csv(os.path.join(OUT_DIR, "m5_sell_price_statistics.csv"))

# calendar event indicators
event_counts = calendar["event_type_1"].value_counts(dropna=True)
event_counts.to_csv(os.path.join(OUT_DIR, "m5_event_type_counts.csv"))
snap_rates = {
    "snap_CA_rate": round(float(calendar["snap_CA"].mean()), 4),
    "snap_TX_rate": round(float(calendar["snap_TX"].mean()), 4),
    "snap_WI_rate": round(float(calendar["snap_WI"].mean()), 4),
}
m5_summary.update(snap_rates)

print("M5 audit complete:", m5_summary)


# ---------------------------------------------------------------------------
# Consolidated summary across all three datasets
# ---------------------------------------------------------------------------
overall = pd.DataFrame([
    {"dataset": "DataCo", **dataco_summary},
    {"dataset": "SCMS", **scms_summary},
])
overall.to_csv(os.path.join(OUT_DIR, "audit_summary_dataco_scms.csv"), index=False)

pd.Series(m5_summary).to_csv(os.path.join(OUT_DIR, "audit_summary_m5.csv"))

print("\nAll audit outputs written to:", OUT_DIR)
for f in sorted(os.listdir(OUT_DIR)):
    print("  -", f)
