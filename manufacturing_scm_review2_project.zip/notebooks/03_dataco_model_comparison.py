# %% [markdown]
# # 03 — DataCo Model Comparison & Selection
#
# Trains Logistic Regression, Random Forest and XGBoost on the SAME
# preprocessing + train/test split to predict `Late_delivery_risk`, then
# compares them on real, executed metrics.

# %%
import pandas as pd
import numpy as np
import time
import json
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                              roc_auc_score, average_precision_score, confusion_matrix,
                              roc_curve, precision_recall_curve)
import xgboost as xgb
import joblib

DATA_DIR = "/home/claude/project/data/processed"
METRICS_DIR = "/home/claude/project/reports/metrics"
FIG_DIR = "/home/claude/project/reports/figures"
MODEL_DIR = "/home/claude/project/models"
for d in [METRICS_DIR, FIG_DIR, MODEL_DIR]:
    os.makedirs(d, exist_ok=True)

RANDOM_STATE = 42

# %% [markdown]
# ## 1. Load the engineered feature matrix produced by
# `02_dataco_feature_engineering.ipynb`

# %%
df = pd.read_csv(os.path.join(DATA_DIR, "dataco_features.csv"))
print("Shape:", df.shape)

TARGET_COL = "Late_delivery_risk"
NUMERIC_FEATURES = ["order_month", "order_weekday", "order_year", "is_weekend_order",
                     "scheduled_shipping_duration", "order_item_quantity", "order_value",
                     "discount_rate", "unit_price", "schedule_tightness_flag"]
CATEGORICAL_FEATURES = ["shipping_mode", "market", "order_region", "category_name",
                         "department_name", "customer_segment"]

X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
y = df[TARGET_COL]

# %% [markdown]
# ## 2. SAME train/test split for all models (fair comparison)

# %%
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
)
print("Train:", X_train.shape, "Test:", X_test.shape)
print("Train target rate:", y_train.mean().round(4), " Test target rate:", y_test.mean().round(4))

# %% [markdown]
# ## 3. SAME preprocessing pipeline for all models
#
# One-hot encode categoricals, standard-scale numerics (scaling only
# matters for Logistic Regression but is harmless for tree models and
# keeps the pipeline identical/fair across all three).

# %%
preprocessor = ColumnTransformer(transformers=[
    ("num", StandardScaler(), NUMERIC_FEATURES),
    ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_FEATURES),
])

# %% [markdown]
# ## 4. Train Logistic Regression, Random Forest, XGBoost

# %%
results = []
fitted_pipelines = {}
proba_store = {}

def evaluate_model(name, pipeline, X_train, y_train, X_test, y_test):
    t0 = time.time()
    pipeline.fit(X_train, y_train)
    train_time = time.time() - t0

    proba = pipeline.predict_proba(X_test)[:, 1]
    pred = (proba >= 0.5).astype(int)

    metrics = {
        "Model": name,
        "Accuracy": accuracy_score(y_test, pred),
        "Precision": precision_score(y_test, pred),
        "Recall": recall_score(y_test, pred),
        "F1": f1_score(y_test, pred),
        "ROC_AUC": roc_auc_score(y_test, proba),
        "PR_AUC": average_precision_score(y_test, proba),
        "Training_Time_Sec": round(train_time, 3),
    }
    fitted_pipelines[name] = pipeline
    proba_store[name] = proba
    return metrics


# --- Logistic Regression ---
logreg_pipe = Pipeline([
    ("prep", preprocessor),
    ("clf", LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)),
])
results.append(evaluate_model("Logistic Regression", logreg_pipe, X_train, y_train, X_test, y_test))
print("Logistic Regression done:", results[-1])

# --- Random Forest ---
rf_pipe = Pipeline([
    ("prep", preprocessor),
    ("clf", RandomForestClassifier(n_estimators=200, max_depth=12, random_state=RANDOM_STATE, n_jobs=-1)),
])
results.append(evaluate_model("Random Forest", rf_pipe, X_train, y_train, X_test, y_test))
print("Random Forest done:", results[-1])

# --- XGBoost ---
xgb_pipe = Pipeline([
    ("prep", preprocessor),
    ("clf", xgb.XGBClassifier(
        n_estimators=300, max_depth=6, learning_rate=0.1,
        subsample=0.9, colsample_bytree=0.9,
        eval_metric="logloss", random_state=RANDOM_STATE, n_jobs=-1
    )),
])
results.append(evaluate_model("XGBoost", xgb_pipe, X_train, y_train, X_test, y_test))
print("XGBoost done:", results[-1])

# %% [markdown]
# ## 5. Model comparison table (REAL executed values)

# %%
comparison_df = pd.DataFrame(results).set_index("Model")
comparison_df = comparison_df.round(4)
comparison_df.to_csv(os.path.join(METRICS_DIR, "dataco_model_comparison.csv"))
comparison_df

# %% [markdown]
# ## 6. Confusion matrices, ROC curves, PR curves

# %%
fig, axes = plt.subplots(1, 3, figsize=(15, 4))
for ax, name in zip(axes, fitted_pipelines.keys()):
    pred = (proba_store[name] >= 0.5).astype(int)
    cm = confusion_matrix(y_test, pred)
    im = ax.imshow(cm, cmap="Blues")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black")
    ax.set_title(name)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_xticks([0, 1]); ax.set_yticks([0, 1])
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "dataco_confusion_matrices.png"), dpi=120)
plt.close()

# %%
plt.figure(figsize=(6, 5))
for name, proba in proba_store.items():
    fpr, tpr, _ = roc_curve(y_test, proba)
    auc_val = roc_auc_score(y_test, proba)
    plt.plot(fpr, tpr, label=f"{name} (AUC={auc_val:.3f})")
plt.plot([0, 1], [0, 1], linestyle="--", color="gray")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("DataCo: ROC curves")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "dataco_roc_curves.png"), dpi=120)
plt.close()

# %%
plt.figure(figsize=(6, 5))
for name, proba in proba_store.items():
    prec, rec, _ = precision_recall_curve(y_test, proba)
    ap_val = average_precision_score(y_test, proba)
    plt.plot(rec, prec, label=f"{name} (PR-AUC={ap_val:.3f})")
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title("DataCo: Precision-Recall curves")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "dataco_pr_curves.png"), dpi=120)
plt.close()

# %%
plt.figure(figsize=(7, 4))
comparison_df[["Accuracy", "Precision", "Recall", "F1", "ROC_AUC"]].plot(kind="bar", figsize=(8, 4))
plt.title("DataCo: model comparison across metrics")
plt.ylabel("score")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "dataco_model_comparison_chart.png"), dpi=120)
plt.close()
print("Saved comparison plots to", FIG_DIR)

# %% [markdown]
# ## 7. Feature importance (best tree-based model)

# %%
best_name = comparison_df["F1"].idxmax()
print("Best model by F1:", best_name)

if best_name in ("Random Forest", "XGBoost"):
    pipe = fitted_pipelines[best_name]
    ohe = pipe.named_steps["prep"].named_transformers_["cat"]
    cat_names = list(ohe.get_feature_names_out(CATEGORICAL_FEATURES))
    all_feature_names = NUMERIC_FEATURES + cat_names
    importances = pipe.named_steps["clf"].feature_importances_
    imp_df = pd.DataFrame({"feature": all_feature_names, "importance": importances})
    imp_df = imp_df.sort_values("importance", ascending=False).head(20)
    imp_df.to_csv(os.path.join(FIG_DIR.replace("figures", "feature_engineering"), "dataco_feature_importance.csv"), index=False)

    plt.figure(figsize=(7, 6))
    plt.barh(imp_df["feature"][::-1], imp_df["importance"][::-1], color="#4C72B0")
    plt.title(f"DataCo: Top 20 feature importances ({best_name})")
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "dataco_feature_importance.png"), dpi=120)
    plt.close()
    print(imp_df.head(10))

# %% [markdown]
# ## 8. Save trained models + predictions/probabilities for reproducibility

# %%
for name, pipe in fitted_pipelines.items():
    fname = name.lower().replace(" ", "_")
    joblib.dump(pipe, os.path.join(MODEL_DIR, f"dataco_{fname}.joblib"))

pred_records = pd.DataFrame({"y_test": y_test.values})
for name, proba in proba_store.items():
    fname = name.lower().replace(" ", "_")
    pred_records[f"{fname}_proba"] = proba
    pred_records[f"{fname}_pred"] = (proba >= 0.5).astype(int)
pred_records.to_csv(os.path.join(METRICS_DIR, "dataco_test_predictions.csv"), index=False)
print("Saved trained models and test-set predictions/probabilities.")

# %% [markdown]
# ## 9. Model selection rationale
#
# Selection is based on BOTH predictive performance and deployment
# considerations, not accuracy alone.

# %%
selection_notes = f"""
DataCo Model Selection — computed from actual results in
reports/metrics/dataco_model_comparison.csv

{comparison_df.to_string()}

Observations (derived directly from the table above):
- Target class balance is close to even (~55/45), see reports/data_audit/dataco_target_distribution.csv,
  so Accuracy is a reasonably informative metric here, but Precision/Recall/F1/ROC-AUC are still
  reported and considered jointly since accuracy alone can hide asymmetric error costs.
- Best model by F1: {best_name}
- Training time is included because in a real deployment pipeline retrained on a schedule,
  a model that is 10x slower to train for a marginal metric gain may not be worth it operationally.
- Tree-based models (Random Forest, XGBoost) can capture non-linear interactions between
  scheduled_shipping_duration, shipping_mode and order_region that Logistic Regression cannot,
  which is the expected mechanism behind any performance gap observed above.
- Interpretability: Logistic Regression coefficients are the most directly explainable to a
  non-technical manufacturing/logistics stakeholder; Random Forest / XGBoost require feature
  importance or SHAP-style explanations instead.
- Manufacturing deployment consideration: False negatives here (predicting on-time when an order
  will actually be late) delay a warehouse/customer response and are generally more costly than
  false positives (flagging an order that turns out on-time), which only cost a wasted precaution.
  This favors selecting a model with strong Recall, not just Accuracy, at the operating point used.
"""
with open(os.path.join(METRICS_DIR, "dataco_model_selection_rationale.txt"), "w") as f:
    f.write(selection_notes)
print(selection_notes)
