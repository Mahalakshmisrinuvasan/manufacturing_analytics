# %% [markdown]
# # 04 — SCMS Feature Engineering
#
# Objective: build a leakage-free feature matrix to predict whether a
# shipment will be **delivered late** relative to its scheduled delivery
# date, using vendor/shipment characteristics known *before* the delivery
# outcome is observed.

# %%
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import os

RAW_DIR = "/mnt/user-data/uploads"
FE_DIR = "/home/claude/project/reports/feature_engineering"
DATA_DIR = "/home/claude/project/data/processed"
os.makedirs(FE_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)
pd.set_option("display.max_columns", None)

# %% [markdown]
# ## 1. Load raw data

# %%
df = pd.read_csv(os.path.join(RAW_DIR, "SCMS_Delivery_History_Dataset.csv"), encoding="utf-8-sig")
print("Raw shape:", df.shape)
df.head(3)

# %% [markdown]
# ## 2. Clean the data
#
# - Parse the dates needed to build the target and the chronological
#   ordering used for historical vendor features.
# - `Weight (Kilograms)` and `Freight Cost (USD)` are stored as text and
#   contain non-numeric placeholders (e.g. "Weight Captured Separately",
#   "Freight Included in Commodity Cost", "See ASN-...") — coerce to
#   numeric and keep a missing-flag rather than dropping the rows, since
#   ~38-40% of rows would be lost otherwise.

# %%
df["Scheduled Delivery Date_parsed"] = pd.to_datetime(df["Scheduled Delivery Date"], errors="coerce")
df["Delivered to Client Date_parsed"] = pd.to_datetime(df["Delivered to Client Date"], errors="coerce")

df["weight_kg"] = pd.to_numeric(df["Weight (Kilograms)"], errors="coerce")
df["weight_missing"] = df["weight_kg"].isna().astype(int)

df["freight_cost_usd"] = pd.to_numeric(df["Freight Cost (USD)"], errors="coerce")
df["freight_missing"] = df["freight_cost_usd"].isna().astype(int)

df_clean = df.dropna(subset=["Scheduled Delivery Date_parsed", "Delivered to Client Date_parsed"]).copy()
print("After cleaning (valid delivery dates):", df_clean.shape)

# %% [markdown]
# ## 3. Build the target from dates (NOT a raw feature)
#
# `delay_days = Delivered to Client Date - Scheduled Delivery Date`.
# `is_late = 1` if `delay_days > 0`.
#
# `Delivered to Client Date` is used ONLY to construct this target column
# and is dropped before modeling — it must never become an input feature,
# since it is only known after the outcome has occurred.

# %%
df_clean["delay_days"] = (df_clean["Delivered to Client Date_parsed"] - df_clean["Scheduled Delivery Date_parsed"]).dt.days
df_clean["is_late"] = (df_clean["delay_days"] > 0).astype(int)

print(df_clean["is_late"].value_counts())
print("Imbalance ratio (on-time : late) =", round((df_clean['is_late']==0).sum() / (df_clean['is_late']==1).sum(), 2))

# %% [markdown]
# ## 4. Chronological ordering for historical (leakage-safe) vendor features
#
# We sort by `Scheduled Delivery Date` (fully populated, 100% parseable,
# unlike `PO Sent to Vendor Date` which is only ~44% parseable) and use
# **expanding / shifted** aggregates so that each row's vendor-history
# features are computed using ONLY rows that came chronologically before
# it. `.shift(1)` on the expanding aggregate guarantees the current row's
# own outcome cannot leak into its own historical feature.

# %%
df_sorted = df_clean.sort_values("Scheduled Delivery Date_parsed").reset_index(drop=True)

# vendor_shipment_count_hist: number of PRIOR shipments seen from this vendor.
# Rationale: vendors with a longer track record in the dataset are typically
# more established suppliers, which can correlate with delivery reliability.
df_sorted["vendor_shipment_count_hist"] = (
    df_sorted.groupby("Vendor").cumcount()
)

# vendor_late_rate_hist: EXPANDING mean of is_late for this vendor, computed
# using only PRIOR rows via shift(1). This is the single most direct proxy
# for "how reliable has this vendor historically been" without leaking the
# current row's own outcome.
df_sorted["_vendor_late_cummean"] = (
    df_sorted.groupby("Vendor")["is_late"].transform(lambda s: s.shift(1).expanding().mean())
)
df_sorted["vendor_late_rate_hist"] = df_sorted["_vendor_late_cummean"]
# For a vendor's first-ever shipment there is no history; fill with the
# global (in-sample, prior-only) late rate up to that point.
global_expanding_rate = df_sorted["is_late"].shift(1).expanding().mean()
df_sorted["vendor_late_rate_hist"] = df_sorted["vendor_late_rate_hist"].fillna(global_expanding_rate)
df_sorted["vendor_late_rate_hist"] = df_sorted["vendor_late_rate_hist"].fillna(df_sorted["is_late"].mean())

# vendor_avg_delay_hist: EXPANDING mean of delay_days for this vendor
# (prior shipments only). Captures the typical magnitude of delay, not
# just whether the vendor tends to be late.
df_sorted["vendor_avg_delay_hist"] = (
    df_sorted.groupby("Vendor")["delay_days"].transform(lambda s: s.shift(1).expanding().mean())
)
df_sorted["vendor_avg_delay_hist"] = df_sorted["vendor_avg_delay_hist"].fillna(
    df_sorted["delay_days"].shift(1).expanding().mean()
).fillna(0)

print("Historical vendor features built. Example rows:")
df_sorted[["Vendor", "Scheduled Delivery Date_parsed", "vendor_shipment_count_hist",
           "vendor_late_rate_hist", "vendor_avg_delay_hist", "is_late"]].head(10)

# %% [markdown]
# ## 5. Remaining domain features (all known at scheduling time)

# %%
feat = df_sorted.copy()

# shipment_mode: Air/Ocean/Truck/etc — structurally different transit
# reliability and susceptibility to delay.
feat["shipment_mode"] = feat["Shipment Mode"]

# fulfill_via: Direct Drop vs From RDC — different logistics chains have
# different delay risk profiles.
feat["fulfill_via"] = feat["Fulfill Via"]

# vendor_inco_term: Incoterms (EXW, FCA, CIP...) affect who is responsible
# for transit legs and therefore delay risk.
feat["vendor_inco_term"] = feat["Vendor INCO Term"]

# product_group / sub_classification: pharma product type; cold-chain /
# controlled substances (e.g. ARV, HRDT) often have stricter, slower
# logistics than others (e.g. MRDT test kits).
feat["product_group"] = feat["Product Group"]
feat["sub_classification"] = feat["Sub Classification"]

# manufacturing_site / country: origin and destination affect customs and
# transit time.
feat["manufacturing_site"] = feat["Manufacturing Site"]
feat["destination_country"] = feat["Country"]

# line_item_quantity / line_item_value / pack_price / unit_price: order
# size and value — larger or higher-value shipments may require extra
# customs/insurance handling that adds delay risk.
feat["line_item_quantity"] = feat["Line Item Quantity"]
feat["line_item_value"] = feat["Line Item Value"]
feat["pack_price"] = feat["Pack Price"]
feat["unit_price"] = feat["Unit Price"]

# weight_kg / freight_cost_usd (+ missing flags): heavier / higher-freight-cost
# shipments can correlate with mode and handling complexity.
# (already created above from raw text columns)

# first_line_designation: whether this is a first-line (standard, well
# established) treatment regimen product - can correlate with more mature/
# reliable supply chains.
feat["first_line_designation"] = feat["First Line Designation"]

# schedule_month / schedule_weekday: seasonality in scheduled delivery date,
# e.g. holiday-season congestion or fiscal year-end order surges.
feat["schedule_month"] = feat["Scheduled Delivery Date_parsed"].dt.month
feat["schedule_weekday"] = feat["Scheduled Delivery Date_parsed"].dt.dayofweek

FEATURE_COLS = [
    "vendor_shipment_count_hist", "vendor_late_rate_hist", "vendor_avg_delay_hist",
    "shipment_mode", "fulfill_via", "vendor_inco_term",
    "product_group", "sub_classification", "manufacturing_site", "destination_country",
    "line_item_quantity", "line_item_value", "pack_price", "unit_price",
    "weight_kg", "weight_missing", "freight_cost_usd", "freight_missing",
    "first_line_designation", "schedule_month", "schedule_weekday",
]
TARGET_COL = "is_late"

print("Final engineered feature columns:")
for c in FEATURE_COLS:
    print(" -", c)

# %% [markdown]
# ## 6. LEAKAGE PREVENTION
#
# | Excluded column | Why it leaks |
# |---|---|
# | `Delivered to Client Date` | used only to construct the target; the outcome itself |
# | `Delivery Recorded Date` | recorded after / at delivery, post-outcome |
# | `delay_days` | this literally *is* (a continuous version of) the target |
# | raw (non-historical) `is_late` per vendor | would need the current row's own outcome |
#
# `vendor_late_rate_hist` / `vendor_avg_delay_hist` are historical
# (shift+expanding) aggregates, not the raw column, so they are safe.

# %%
LEAKAGE_COLS = ["Delivered to Client Date", "Delivery Recorded Date", "delay_days"]
leak_found = [c for c in LEAKAGE_COLS if c in FEATURE_COLS]
assert len(leak_found) == 0, f"Leakage columns present: {leak_found}"
print("PASS: no leakage columns present in FEATURE_COLS.")
print("Excluded columns:", LEAKAGE_COLS)

# %% [markdown]
# ## 7. Save processed feature matrix

# %%
model_df = feat[FEATURE_COLS + [TARGET_COL]].copy()
# numeric NaNs (e.g. weight/freight still missing after coercion) filled with
# 0 alongside their already-created *_missing indicator flags, so the model
# can learn "missingness" is informative without dropping ~40% of rows.
model_df["weight_kg"] = model_df["weight_kg"].fillna(0)
model_df["freight_cost_usd"] = model_df["freight_cost_usd"].fillna(0)
model_df = model_df.dropna()
print("Modeling matrix shape:", model_df.shape)
model_df.to_csv(os.path.join(DATA_DIR, "scms_features.csv"), index=False)
print("Saved:", os.path.join(DATA_DIR, "scms_features.csv"))

# %% [markdown]
# ## 8. Before/after feature table

# %%
summary_rows = [
    ("Vendor (raw)", "vendor_shipment_count_hist, vendor_late_rate_hist, vendor_avg_delay_hist",
     "Raw vendor ID has too many categories to encode directly; replaced with leakage-safe expanding historical performance stats (shift(1) so the current row's own outcome never leaks in)."),
    ("Shipment Mode", "shipment_mode", "Kept; Air/Ocean/Truck differ structurally in delay risk."),
    ("Fulfill Via", "fulfill_via", "Kept; Direct Drop vs from-RDC changes the logistics chain."),
    ("Vendor INCO Term", "vendor_inco_term", "Kept; Incoterms affect who owns each transit leg."),
    ("Product Group / Sub Classification", "product_group, sub_classification", "Kept; product type affects handling/cold-chain needs."),
    ("Manufacturing Site / Country", "manufacturing_site, destination_country", "Kept; origin/destination affect customs and transit time."),
    ("Line Item Quantity / Value, Pack/Unit Price", "line_item_quantity, line_item_value, pack_price, unit_price", "Kept; shipment size/value affects handling complexity."),
    ("Weight (Kilograms)", "weight_kg, weight_missing", "Coerced text->numeric; ~38% were non-numeric placeholders, so a missingness flag was added instead of dropping those rows."),
    ("Freight Cost (USD)", "freight_cost_usd, freight_missing", "Same treatment as weight; ~40% were text placeholders like 'Freight Included in Commodity Cost'."),
    ("First Line Designation", "first_line_designation", "Kept; correlates with supply-chain maturity for that product."),
    ("Scheduled Delivery Date", "schedule_month, schedule_weekday", "Decomposed for seasonality signal known at scheduling time."),
    ("Delivered to Client Date", "used to build target only, then EXCLUDED", "Post-outcome; would leak the answer directly."),
    ("Delivery Recorded Date", "EXCLUDED (leakage)", "Recorded at/after delivery."),
]
fe_table = pd.DataFrame(summary_rows, columns=["Original Feature", "Engineered Feature", "Reason"])
fe_table.insert(0, "Dataset", "SCMS")
fe_table.to_csv(os.path.join(FE_DIR, "scms_feature_table.csv"), index=False)
fe_table

# %% [markdown]
# ## 9. Exploratory plots

# %%
plt.figure(figsize=(6, 4))
model_df.groupby("shipment_mode")[TARGET_COL].mean().sort_values().plot(kind="barh", color="#4C72B0")
plt.xlabel("Late-delivery rate")
plt.title("SCMS: Late-delivery rate by shipment mode")
plt.tight_layout()
plt.savefig(os.path.join(FE_DIR, "scms_late_rate_by_shipment_mode.png"), dpi=120)
plt.close()

plt.figure(figsize=(6, 4))
plt.scatter(model_df["vendor_late_rate_hist"], model_df[TARGET_COL], alpha=0.05, s=10)
plt.xlabel("vendor_late_rate_hist (historical, leakage-safe)")
plt.ylabel("is_late (current shipment)")
plt.title("SCMS: historical vendor late-rate vs current outcome")
plt.tight_layout()
plt.savefig(os.path.join(FE_DIR, "scms_vendor_hist_vs_outcome.png"), dpi=120)
plt.close()
print("Saved SCMS feature-engineering plots.")

# %% [markdown]
# ## 10. Final feature list

# %%
with open(os.path.join(FE_DIR, "scms_final_feature_list.txt"), "w") as f:
    f.write("Target: " + TARGET_COL + " (1 = delivered after Scheduled Delivery Date)\n\n")
    f.write("Final model features:\n")
    for c in FEATURE_COLS:
        f.write(f" - {c}\n")
    f.write("\nExcluded (leakage) columns:\n")
    for c in LEAKAGE_COLS:
        f.write(f" - {c}\n")
print("SCMS feature engineering complete.")
