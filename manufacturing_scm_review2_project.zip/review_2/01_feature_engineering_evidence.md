# 01 — Feature Engineering Evidence

Everything in this document is generated from code that was actually
executed against the uploaded datasets. Source files (all executed,
outputs saved):

- `notebooks/02_dataco_feature_engineering.ipynb`
- `notebooks/04_scms_feature_engineering.ipynb`
- `notebooks/06_m5_feature_engineering.ipynb`

Outputs referenced below live in `reports/feature_engineering/` and
`data/processed/`.

## DataCo — `Late_delivery_risk` prediction

Raw dataset: 180,519 rows x 53 columns (`reports/data_audit/dataco_column_summary.csv`).

16 engineered features were built from order-time-available information only
(see `reports/feature_engineering/dataco_final_feature_list.txt` and
`dataco_feature_table.csv`):

`order_month, order_weekday, order_year, is_weekend_order,
scheduled_shipping_duration, order_item_quantity, order_value,
discount_rate, unit_price, shipping_mode, market, order_region,
category_name, department_name, customer_segment, schedule_tightness_flag`

Three columns were deliberately **excluded** for leakage
(`Days for shipping (real)`, `Delivery Status`, `Order Status`) — verified
programmatically in `reports/data_leakage_check.md`.

Final processed feature matrix: `data/processed/dataco_features.csv`
(180,519 rows x 17 columns including target).

Supporting plots: `dataco_late_rate_by_shipping_mode.png`,
`dataco_late_rate_by_schedule.png` (both in `reports/feature_engineering/`).

## SCMS — `is_late` (delivery delay) prediction

Raw dataset: 10,324 rows x 33 columns.

Key engineering challenge: `Vendor` has too many distinct values to
one-hot encode directly, so three **leakage-safe historical vendor
features** were built using `shift(1)` + `expanding()` aggregates, sorted
by `Scheduled Delivery Date` (the only fully-populated date column):
`vendor_shipment_count_hist`, `vendor_late_rate_hist`,
`vendor_avg_delay_hist`. This guarantees a row's own outcome never
contributes to its own historical feature.

`Weight (Kilograms)` and `Freight Cost (USD)` were stored as text with
non-numeric placeholders (e.g. "Weight Captured Separately",
"Freight Included in Commodity Cost") in ~38-40% of rows — coerced to
numeric with an accompanying `*_missing` indicator flag rather than
dropping those rows.

21 final features total — see
`reports/feature_engineering/scms_final_feature_list.txt` and
`scms_feature_table.csv` for the complete before/after mapping.

Final processed feature matrix: `data/processed/scms_features.csv`
(9,965 rows x 22 columns).

Supporting plots: `scms_late_rate_by_shipment_mode.png`,
`scms_vendor_hist_vs_outcome.png`.

## M5 — demand forecasting

**Documented subset**: the top 500 highest-volume items from store `CA_1`
(full 1,913-day history each). An initial attempt using all 3,049 items
from `CA_1` exhausted this environment's ~4GB memory ceiling and crashed
the kernel — this is stated explicitly rather than hidden; see the markdown
cell at the top of `06_m5_feature_engineering.ipynb`.

18 features engineered: `lag_1, lag_7, lag_14, lag_28, rolling_mean_7,
rolling_std_7, rolling_mean_28, day_of_week, month, year, is_event,
snap_day, price, price_change, price_change_pct, item_id, dept_id, cat_id`.

All lag/rolling features are computed per-series via
`groupby("id").shift(...)` / `.shift(1).rolling(...)`, which is inherently
leakage-safe — no feature for day *t* can see day *t* or later.

Time-aware split (no shuffling): train ends 2016-03-27, validation begins
2016-03-28 (28-day validation window) — verified in
`reports/data_leakage_check.md`.

Final processed files: `data/processed/m5_features_train.csv` (928,500 rows),
`m5_features_val.csv` (14,000 rows).

## Before/after feature tables (all three datasets)

- `reports/feature_engineering/dataco_feature_table.csv`
- `reports/feature_engineering/scms_feature_table.csv`
- `reports/feature_engineering/m5_feature_table.csv`

## Feature importance (generated after model training — see notebooks 03, 05, 07)

- `reports/feature_engineering/dataco_feature_importance.csv` + `reports/figures/dataco_feature_importance.png`
- `reports/feature_engineering/scms_feature_importance.csv` + `reports/figures/scms_feature_importance.png`
- `reports/feature_engineering/m5_feature_importance.csv` + `reports/figures/m5_feature_importance.png`
