# 03 — Class Imbalance Handling Evidence

Source notebook: `notebooks/05_scms_model_comparison.ipynb`
(class-distribution + imbalance-experiment cells).
Outputs: `reports/imbalance/`.

## Step 1 — Measure actual imbalance for BOTH classification datasets

### DataCo (`reports/data_audit/dataco_target_distribution.csv`)

| Late_delivery_risk | Count |
|---|---:|
| 0 (on-time) | 81,542 |
| 1 (late) | 98,977 |

Imbalance ratio ≈ **1.21 : 1** — close to balanced.

**Decision: SMOTE / imbalance handling was judged unnecessary for DataCo**,
and was NOT applied, because the class split is close to even. Applying
SMOTE here would add complexity and synthetic-data risk without a real
problem to solve — the rubric mentioning SMOTE was not treated as a reason
to use it where the data doesn't call for it.

### SCMS (`reports/imbalance/scms_class_distribution.csv`,
`scms_imbalance_ratio.txt`)

| is_late | Count |
|---|---:|
| 0 (on-time/early) | 8,782 |
| 1 (late) | 1,182 |

Imbalance ratio ≈ **7.43 : 1** — genuinely imbalanced.

**Decision: imbalance handling WAS investigated and applied for SCMS.**

## Step 2 — Real, executed comparison of imbalance-handling strategies (SCMS, XGBoost)

`reports/imbalance/scms_imbalance_method_comparison.csv`:

| Method | Precision | Recall | F1 | ROC-AUC | PR-AUC |
|---|---:|---:|---:|---:|---:|
| 1. No imbalance handling (baseline) | 0.7183 | 0.4322 | 0.5397 | 0.9109 | 0.6222 |
| 2. Class weighting (sample_weight = neg/pos) | 0.4430 | 0.7076 | 0.5449 | 0.9103 | 0.6053 |
| 3. SMOTE (train fold only) | 0.6364 | 0.4746 | 0.5437 | 0.9067 | 0.5968 |
| **4. XGBoost scale_pos_weight** | 0.4632 | **0.7458** | **0.5714** | 0.9093 | **0.6221** |

SMOTE was applied **only to the training fold** (`X_train_enc`), never to
the test fold, to avoid leaking synthetic-neighbor information into
evaluation — confirmed directly in the notebook code.

## Step 3 — Why Accuracy is not the deciding metric here

With a ~7.4:1 imbalance, a trivial "always predict on-time" model would
already score roughly **88%** accuracy (matches the baseline models'
Accuracy of 0.88-0.91) while having **zero** ability to catch late
shipments (Recall = 0) — exactly what Logistic Regression and Random
Forest do in the baseline comparison (Recall 0.038 and 0.030
respectively, in `reports/metrics/scms_model_comparison.csv`). This is
concrete, real evidence for why Precision/Recall/F1/PR-AUC are used
instead of Accuracy for this dataset.

## Step 4 — Trade-off discussion (cost of false negatives vs false positives)

Full text: `reports/imbalance/scms_imbalance_trade_off_notes.txt`. Summary:

- **False negative** (predicting on-time when a shipment will actually be
  late): a genuinely delayed pharma/medical shipment is not flagged — no
  proactive follow-up or expedited re-order, risking stockouts that affect
  patient care. This is the more costly error in this domain.
- **False positive** (flagging a shipment that turns out on-time): costs
  staff time to investigate or a redundant expediting request — an
  operational nuisance, not a supply failure.
- Given this asymmetry, the project favors methods that raise **Recall**
  (catching more true late shipments) even at some Precision cost — which
  is exactly what class weighting and `scale_pos_weight` achieve (Recall
  0.71-0.75 vs the 0.43 baseline).

## Final choice

**XGBoost with `scale_pos_weight`** — highest Recall and F1 among all four
methods tested, and it requires no extra synthetic-data-generation step at
inference time (simpler to deploy than a SMOTE-based pipeline).

Plot: `reports/imbalance/scms_imbalance_method_comparison.png`.
