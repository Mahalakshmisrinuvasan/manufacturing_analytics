# 02 — Model Selection Evidence

Source notebooks (all executed, outputs saved):
`notebooks/03_dataco_model_comparison.ipynb`,
`notebooks/05_scms_model_comparison.ipynb`,
`notebooks/07_m5_forecasting.ipynb`.

Regenerate the consolidated view any time with:
`python3 src/models/05_model_comparison.py`

## DataCo — Late_delivery_risk (real executed results)

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC | PR-AUC | Training Time (s) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Logistic Regression | 0.6968 | 0.8500 | 0.5427 | 0.6625 | 0.7295 | 0.7993 | 1.0 |
| Random Forest | 0.7000 | 0.8423 | 0.5572 | 0.6707 | 0.7398 | 0.8082 | 54.9 |
| **XGBoost** | 0.6984 | 0.8262 | 0.5699 | **0.6745** | **0.7457** | **0.8121** | 4.1 |

**Selected: XGBoost.** Best F1, ROC-AUC and PR-AUC; ~13x faster to train
than Random Forest for a better score. Full rationale text:
`reports/metrics/dataco_model_selection_rationale.txt`.

## SCMS — is_late (real executed results)

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC | PR-AUC | Training Time (s) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Logistic Regression | 0.8826 | 0.5625 | 0.0381 | 0.0714 | 0.8149 | 0.3276 | 0.10 |
| Random Forest | 0.8841 | 0.7778 | 0.0297 | 0.0571 | 0.9016 | 0.5456 | 3.8 |
| **XGBoost** | 0.9127 | 0.7183 | 0.4322 | **0.5397** | **0.9109** | **0.6222** | 0.4 |

XGBoost is the clear best baseline learner (Logistic Regression and Random
Forest both have near-zero Recall — they essentially default to predicting
"on-time" for almost everything, which the ~7.4:1 class imbalance makes
easy to do well on Accuracy but useless in practice). XGBoost was then
carried forward into the dedicated imbalance-handling experiment — see
`03_class_imbalance_evidence.md`.

**Selected final configuration: XGBoost with `scale_pos_weight`** (Recall
0.7458, F1 0.5714 — see imbalance evidence doc for the full comparison).

## M5 — units_sold (real executed results)

| Model | MAE | RMSE | MAPE (%) |
|---|---:|---:|---:|
| Seasonal Naive (t-7) | 3.4501 | 5.9352 | 92.66 |
| **LightGBM** | **2.5542** | **4.2024** | **78.71** |

**Selected: LightGBM.** 26.0% MAE improvement over the seasonal-naive
benchmark on the strictly time-forward validation window (last 28 days).

## Selection rationale (performance + deployment, per dataset)

Full written rationale for each dataset (predictive performance,
interpretability, training time, computational requirements, manufacturing
deployment considerations) is saved at:

- `reports/metrics/dataco_model_selection_rationale.txt`
- `reports/metrics/scms_model_selection_rationale.txt`
- `reports/metrics/m5_model_selection_rationale.txt`

None of these models were selected on Accuracy alone — see
`03_class_imbalance_evidence.md` for why Accuracy is explicitly
insufficient for SCMS, and `04_model_evaluation_evidence.md` for the full
metric set behind each choice.
