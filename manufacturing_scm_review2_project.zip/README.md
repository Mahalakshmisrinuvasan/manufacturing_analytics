# AI-Powered Manufacturing Supply Chain Analytics & Decision Intelligence

A college mini-project analyzing supply chain risk and demand across three
real datasets:

| Module | Dataset | Task |
|---|---|---|
| Delivery Risk Prediction | DataCo Supply Chain Dataset | Classify whether an order will be delivered late (`Late_delivery_risk`) |
| Supplier / Shipment Risk Prediction | SCMS Delivery History Dataset | Classify whether a shipment will arrive after its scheduled date (`is_late`) |
| Demand Forecasting | M5 Forecasting dataset (sales + prices + calendar) | Forecast daily unit demand |

Their outputs are designed to eventually feed a shared analytical
decision layer; for Review 2 the priority is real, executed evidence for
each module independently.

## Quick start

```bash
pip install -r requirements.txt
```

Place the raw datasets as described in `data/README.md`, then run the
notebooks in order (01 → 07) — see `review_2/05_reproducibility_evidence.md`
for exact commands.

## Repository structure

```
project/
├── notebooks/       <- primary evidence: 7 executed Jupyter notebooks
├── src/              <- standalone reproducibility/leakage-check scripts
├── data/              <- raw data instructions + processed feature matrices
├── models/            <- trained model artifacts
├── reports/            <- all generated tables, plots, and text evidence
└── review_2/            <- Review 2 evidence documents (start here)
```

## Where to start

- **Reviewer / grader**: read `REVIEWER_DEMO.md` for a direct mapping of
  "if the reviewer asks X, open file Y."
- **Full evidence summary**: `review_2/REVIEW_2_SUMMARY.md`.
- **Methodology detail**: `review_2/01_feature_engineering_evidence.md`
  through `05_reproducibility_evidence.md`.

## Key real results (see `reports/metrics/` for the full tables)

- **DataCo**: XGBoost, F1 = 0.6745, ROC-AUC = 0.7457 (vs Logistic
  Regression F1 = 0.6625, Random Forest F1 = 0.6707).
- **SCMS**: XGBoost + `scale_pos_weight`, Recall = 0.7458, F1 = 0.5714
  (baseline XGBoost without imbalance handling: Recall = 0.4322).
- **M5**: LightGBM, MAE = 2.5542 — a 26.0% improvement over the Seasonal
  Naive (t-7) baseline (MAE = 3.4501).

## Design notes

- Transparent, auditable modeling (Logistic Regression / Random Forest /
  XGBoost / LightGBM with clear metrics) was prioritized over black-box
  or overengineered approaches, matching the project's mini-project scope.
- Leakage prevention was treated as a first-class concern, not an
  afterthought — see `reports/data_leakage_check.md` for a programmatic
  pass/fail check on every feature matrix.
- Class imbalance handling was applied only where the data actually
  showed meaningful imbalance (SCMS), not applied by default everywhere
  (DataCo is close to balanced and SMOTE was deliberately skipped there,
  with reasoning).

## License / academic use

This is a student mini-project. Datasets used are third-party (DataCo,
SCMS/USAID, Walmart M5) and are not redistributed in this repository —
see `data/README.md`.
