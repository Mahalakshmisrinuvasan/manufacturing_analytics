# AI-Powered Manufacturing Supply Chain Analytics — Backend

Backend-only system (no frontend) for:
1. **DataCo** — Delivery Risk classification (On-Time vs Late)
2. **SCMS** — Supplier/Shipment Delay classification (On-Time vs Delayed)
3. **M5** — Demand Forecasting (time series)

All data is synthetic but generated with realistic, noisy latent risk
functions (not hardcoded outcomes), and every metric in `results/` was
produced by actually fitting and evaluating the corresponding model.

## Setup

```bash
cd backend
python3 -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt
```

## Regenerate data + retrain everything from scratch

Model artifacts (`models/`) and result files (`results/`) are already
included so the API works immediately. To regenerate everything from
scratch (same random seeds, so results will match):

```bash
python3 -m scripts.run_all
```

This runs, in order: generate DataCo/SCMS/M5 synthetic data → train each
domain's full pipeline (preprocessing → feature engineering → train/test
split → multiple models × imbalance strategies → evaluation → comparison
→ best-model selection → persist to `models/` and `results/`).

You can also run each stage individually, e.g.:
```bash
python3 -m ml.dataco.generate_data
python3 -m ml.dataco.train
```

## Run the API

```bash
uvicorn app.main:app --reload --port 8000
```

Interactive docs: http://localhost:8000/docs

## Endpoints

| Method | Path | Description |
|---|---|---|
| GET  | `/api/health` | Service + pipeline-readiness status |
| GET  | `/api/project-summary` | High-level summary of all 3 systems + best models |
| GET  | `/api/dataco/results` | All DataCo experiment results, comparison, best model |
| POST | `/api/dataco/predict` | Predict On-Time/Late for a new order |
| GET  | `/api/scms/results` | All SCMS experiment results, comparison, best model |
| GET  | `/api/scms/imbalance` | No-Handling vs Class-Weight vs SMOTE comparison |
| POST | `/api/scms/predict` | Predict On-Time/Delayed for a new shipment |
| GET  | `/api/m5/results` | Naive/Seasonal-Naive/ARIMA/XGBoost comparison (MAE/RMSE/MAPE) |
| POST | `/api/m5/forecast` | Recursive N-day forecast for a (store_id, item_id) series |
| GET  | `/api/models/comparison` | Combined model comparison across all 3 domains |
| GET  | `/api/features` | Full feature store (name, formula, business meaning, reason) |
| GET  | `/api/justifications` | Per-model metrics, interpretability, strengths/limitations, selected/rejected + reason |

### Example: DataCo predict
```bash
curl -X POST http://localhost:8000/api/dataco/predict \
  -H "Content-Type: application/json" \
  -d '{
    "shipping_mode": "Same Day",
    "order_region": "APAC",
    "product_category": "Furniture",
    "product_weight_kg": 35.0,
    "order_quantity": 8,
    "unit_price": 300,
    "discount_rate": 0.35,
    "distance_km": 5000,
    "scheduled_shipping_days": 2
  }'
```

### Example: SCMS predict
```bash
curl -X POST http://localhost:8000/api/scms/predict \
  -H "Content-Type: application/json" \
  -d '{
    "supplier_name": "Supplier E",
    "supplier_reliability_score": 0.60,
    "supplier_past_delay_rate": 0.40,
    "shipment_mode": "Ocean",
    "lead_time_days": 50,
    "typical_lead_time_days": 35,
    "order_quantity": 18000,
    "unit_cost": 3.0,
    "destination_region": "Sub-Saharan Africa",
    "distance_km": 9500
  }'
```

### Example: M5 forecast
```bash
curl -X POST http://localhost:8000/api/m5/forecast \
  -H "Content-Type: application/json" \
  -d '{"store_id": "STORE_1", "item_id": "ITEM_A_FOODS", "horizon_days": 14}'
```
Available series: `STORE_1|ITEM_A_FOODS`, `STORE_1|ITEM_B_HOUSEHOLD`,
`STORE_2|ITEM_A_FOODS`, `STORE_2|ITEM_C_HOBBIES`.

## Pipeline (per classification domain)

```
Synthetic Data → Preprocessing → Domain Feature Engineering →
Train/Test Split (stratified 80/20) → 3 models × 3 imbalance strategies
(No Handling / Class Weight / SMOTE-train-only) → Evaluation
(Precision, Recall, F1, ROC-AUC, Confusion Matrix) → Model Comparison
→ Best Model Selection (by F1, ROC-AUC tiebreak) → Persist (joblib + JSON/CSV)
```

## Pipeline (M5 forecasting)

```
Synthetic Data → Domain Feature Engineering (lag 1/7/14/28, rolling
mean/std, calendar, price, promo) → Chronological Split (last 60 days
held out) → Naive / Seasonal Naive / ARIMA(1,1,1)(1,1,1,7) / XGBoost →
Evaluation (MAE, RMSE, MAPE) → Comparison → Best Model Selection (by MAPE)
```
Note: Naive/Seasonal-Naive/XGBoost are evaluated one-step-ahead using true
lag features (standard walk-forward setup); ARIMA performs genuine
multi-step forecasting per series. `/api/m5/forecast` itself is fully
recursive multi-step (each predicted day feeds the next day's lag
features).

## Notes on integrity

- Nothing is hardcoded: every number in `results/*.json` comes from an
  actual `model.fit()` / `model.predict()` call against a held-out split.
- SMOTE is applied to the training fold only, never to test data.
- Target encodings (e.g. shipping-mode risk, supplier risk) are fit on
  the training fold only, to avoid leakage into engineered features.
- Re-running `scripts/run_all.py` reproduces identical results (fixed
  random seeds per module).
