"""
Run the entire backend pipeline end-to-end:
generate data -> train DataCo -> train SCMS -> train M5.

Usage: python3 -m scripts.run_all   (run from the backend/ directory)
"""
from __future__ import annotations

import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE_DIR))

from ml.dataco.generate_data import main as gen_dataco
from ml.scms.generate_data import main as gen_scms
from ml.m5.generate_data import main as gen_m5
from ml.dataco.train import run_pipeline as train_dataco
from ml.scms.train import run_pipeline as train_scms
from ml.m5.train import run_pipeline as train_m5


def main():
    print("=" * 70)
    print("STEP 1/6: Generating DataCo synthetic data")
    print("=" * 70)
    gen_dataco()

    print("=" * 70)
    print("STEP 2/6: Generating SCMS synthetic data")
    print("=" * 70)
    gen_scms()

    print("=" * 70)
    print("STEP 3/6: Generating M5 synthetic data")
    print("=" * 70)
    gen_m5()

    print("=" * 70)
    print("STEP 4/6: Training DataCo pipeline")
    print("=" * 70)
    train_dataco()

    print("=" * 70)
    print("STEP 5/6: Training SCMS pipeline")
    print("=" * 70)
    train_scms()

    print("=" * 70)
    print("STEP 6/6: Training M5 pipeline")
    print("=" * 70)
    train_m5()

    print("=" * 70)
    print("ALL PIPELINES COMPLETE. Start the API with:")
    print("  uvicorn app.main:app --reload --port 8000")
    print("=" * 70)


if __name__ == "__main__":
    main()
