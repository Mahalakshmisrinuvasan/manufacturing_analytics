from __future__ import annotations

import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE_DIR))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers import dataco, scms, m5, meta

app = FastAPI(
    title="AI-Powered Manufacturing Supply Chain Analytics API",
    description=(
        "Backend for delivery-risk classification (DataCo), supplier/shipment-delay "
        "classification (SCMS), and demand forecasting (M5-style). Real synthetic "
        "data, real experiments, real metrics -- no hardcoded results."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(meta.router)
app.include_router(dataco.router)
app.include_router(scms.router)
app.include_router(m5.router)


@app.get("/")
def root():
    return {
        "message": "AI-Powered Manufacturing Supply Chain Analytics API",
        "docs": "/docs",
        "health": "/api/health",
    }
