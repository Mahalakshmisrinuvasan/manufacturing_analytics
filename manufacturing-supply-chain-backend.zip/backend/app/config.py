from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]  # backend/
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
RESULTS_DIR = BASE_DIR / "results"

DATACO_RESULTS = RESULTS_DIR / "dataco"
SCMS_RESULTS = RESULTS_DIR / "scms"
M5_RESULTS = RESULTS_DIR / "m5"

DATACO_MODELS = MODELS_DIR / "dataco"
SCMS_MODELS = MODELS_DIR / "scms"
M5_MODELS = MODELS_DIR / "m5"
