from __future__ import annotations

from datetime import date
from typing import Optional

from pydantic import BaseModel, Field


class DataCoPredictRequest(BaseModel):
    shipping_mode: str = Field(..., examples=["Standard Class"])
    order_region: str = Field(..., examples=["North America"])
    product_category: str = Field(..., examples=["Electronics"])
    product_weight_kg: float = Field(..., gt=0)
    order_quantity: int = Field(..., gt=0)
    unit_price: float = Field(..., gt=0)
    discount_rate: float = Field(..., ge=0, le=0.9)
    distance_km: float = Field(..., gt=0)
    scheduled_shipping_days: int = Field(..., gt=0)
    order_date: Optional[date] = None


class DataCoPredictResponse(BaseModel):
    prediction: str  # "On-Time" | "Late"
    late_probability: float
    model_used: str
    imbalance_strategy_used: str


class SCMSPredictRequest(BaseModel):
    supplier_name: str = Field(..., examples=["Supplier A"])
    supplier_reliability_score: float = Field(..., ge=0, le=1)
    supplier_past_delay_rate: float = Field(..., ge=0, le=1)
    shipment_mode: str = Field(..., examples=["Air"])
    lead_time_days: float = Field(..., gt=0)
    typical_lead_time_days: float = Field(..., gt=0)
    order_quantity: int = Field(..., gt=0)
    unit_cost: float = Field(..., gt=0)
    destination_region: str = Field(..., examples=["Southeast Asia"])
    distance_km: float = Field(..., gt=0)


class SCMSPredictResponse(BaseModel):
    prediction: str  # "On-Time" | "Delayed"
    delay_probability: float
    model_used: str
    imbalance_strategy_used: str


class M5ForecastRequest(BaseModel):
    store_id: str = Field(..., examples=["STORE_1"])
    item_id: str = Field(..., examples=["ITEM_A_FOODS"])
    horizon_days: int = Field(14, ge=1, le=28)
    assumed_sell_price: Optional[float] = None
    assumed_promotion: bool = False


class M5ForecastDay(BaseModel):
    date: str
    forecast_units: float


class M5ForecastResponse(BaseModel):
    store_id: str
    item_id: str
    model_used: str
    forecast: list[M5ForecastDay]
    assumptions: dict
