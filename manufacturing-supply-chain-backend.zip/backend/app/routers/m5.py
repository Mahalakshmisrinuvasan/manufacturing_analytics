from __future__ import annotations

import json
import sys
from functools import lru_cache
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from fastapi import APIRouter, HTTPException

BASE_DIR = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE_DIR))

from app.config import M5_RESULTS, M5_MODELS
from app.schemas import M5ForecastRequest, M5ForecastResponse, M5ForecastDay

router = APIRouter(prefix="/api/m5", tags=["M5 - Demand Forecasting"])


def _read_json(path: Path):
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"Results not found: {path.name}. Run the training pipeline first.")
    with open(path) as f:
        return json.load(f)


@lru_cache(maxsize=1)
def _load_model():
    path = M5_MODELS / "xgboost.joblib"
    meta_path = M5_MODELS / "xgboost_meta.joblib"
    if not path.exists() or not meta_path.exists():
        raise HTTPException(status_code=404, detail="M5 model not trained yet. Run scripts/run_all.py.")
    model = joblib.load(path)
    meta = joblib.load(meta_path)
    return model, meta["feature_columns"]


@lru_cache(maxsize=1)
def _load_history():
    return _read_json(M5_RESULTS / "recent_history.json")


@router.get("/results")
def get_results():
    return {
        "best_model": _read_json(M5_RESULTS / "best_model.json"),
        "model_comparison": _read_json(M5_RESULTS / "model_comparison.json"),
        "all_results": _read_json(M5_RESULTS / "all_results.json"),
    }


@router.post("/forecast", response_model=M5ForecastResponse)
def forecast(req: M5ForecastRequest):
    model, feature_columns = _load_model()
    history = _load_history()

    key = f"{req.store_id}|{req.item_id}"
    if key not in history:
        available = sorted(set(k for k in history.keys()))
        raise HTTPException(
            status_code=404,
            detail=f"No history found for store_id='{req.store_id}', item_id='{req.item_id}'. "
                   f"Available series: {available}",
        )

    series = history[key]
    dates = pd.to_datetime(series["dates"])
    units = list(series["units_sold"])
    last_price = series["sell_price"][-1]
    sell_price = req.assumed_sell_price if req.assumed_sell_price is not None else last_price
    promo_flag = int(req.assumed_promotion)

    last_date = dates[-1]
    forecast_days = []

    for step in range(1, req.horizon_days + 1):
        future_date = last_date + pd.Timedelta(days=step)

        lag_1 = units[-1]
        lag_7 = units[-7] if len(units) >= 7 else units[0]
        lag_14 = units[-14] if len(units) >= 14 else units[0]
        lag_28 = units[-28] if len(units) >= 28 else units[0]

        # rolling stats computed over the trailing window BEFORE this day,
        # matching the shift(1)-then-rolling logic used at training time
        window7 = units[-7:] if len(units) >= 3 else units
        window28 = units[-28:] if len(units) >= 7 else units
        rolling_mean_7 = float(np.mean(window7))
        rolling_mean_28 = float(np.mean(window28))
        rolling_std_7 = float(np.std(window7, ddof=1)) if len(window7) > 1 else 0.0

        row = {
            "lag_1": lag_1, "lag_7": lag_7, "lag_14": lag_14, "lag_28": lag_28,
            "rolling_mean_7": rolling_mean_7, "rolling_mean_28": rolling_mean_28,
            "rolling_std_7": rolling_std_7,
            "day_of_week": future_date.dayofweek, "month": future_date.month,
            "is_weekend": int(future_date.dayofweek >= 5),
            "sell_price": sell_price, "promotion_flag": promo_flag,
        }
        for col in feature_columns:
            if col.startswith("store_id_"):
                row[col] = 1 if col == f"store_id_{req.store_id}" else 0
            elif col.startswith("item_id_"):
                row[col] = 1 if col == f"item_id_{req.item_id}" else 0

        X = pd.DataFrame([row]).reindex(columns=feature_columns, fill_value=0)
        pred = float(np.clip(model.predict(X)[0], 0, None))

        forecast_days.append(M5ForecastDay(date=future_date.strftime("%Y-%m-%d"), forecast_units=round(pred, 2)))
        units.append(pred)  # feed prediction back in for next step's lags (recursive forecasting)

    return M5ForecastResponse(
        store_id=req.store_id,
        item_id=req.item_id,
        model_used="xgboost",
        forecast=forecast_days,
        assumptions={
            "sell_price_assumed": sell_price,
            "promotion_assumed": bool(req.assumed_promotion),
            "note": "Recursive multi-step forecast: each day's prediction feeds the lag features "
                    "for subsequent days, so error can compound further into the horizon. "
                    "Price/promotion are held constant at the assumed values for the whole horizon "
                    "unless overridden per request.",
        },
    )
