from __future__ import annotations

import json
import sys
from pathlib import Path

from fastapi import APIRouter, HTTPException

BASE_DIR = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE_DIR))

from app.config import DATACO_RESULTS, SCMS_RESULTS, M5_RESULTS

router = APIRouter(prefix="/api", tags=["Meta"])


def _read_json(path: Path, required: bool = True):
    if not path.exists():
        if required:
            raise HTTPException(status_code=404, detail=f"Results not found: {path}. Run the training pipeline first.")
        return None
    with open(path) as f:
        return json.load(f)


@router.get("/health")
def health():
    domains_ready = {
        "dataco": (DATACO_RESULTS / "best_model.json").exists(),
        "scms": (SCMS_RESULTS / "best_model.json").exists(),
        "m5": (M5_RESULTS / "best_model.json").exists(),
    }
    return {
        "status": "ok",
        "service": "Manufacturing Supply Chain Analytics API",
        "pipelines_trained": domains_ready,
        "all_ready": all(domains_ready.values()),
    }


@router.get("/project-summary")
def project_summary():
    dataco_best = _read_json(DATACO_RESULTS / "best_model.json", required=False)
    scms_best = _read_json(SCMS_RESULTS / "best_model.json", required=False)
    m5_best = _read_json(M5_RESULTS / "best_model.json", required=False)

    return {
        "project": "AI-Powered Manufacturing Supply Chain Analytics",
        "description": (
            "Three synthetic-data ML systems covering delivery risk classification "
            "(DataCo), supplier/shipment delay classification (SCMS), and demand "
            "forecasting (M5-style), built on a common pipeline: Synthetic Data -> "
            "Preprocessing -> Domain Feature Engineering -> Train/Test Split -> "
            "Multiple Models -> Imbalance Handling -> Evaluation -> Model Comparison "
            "-> Best Model Selection."
        ),
        "systems": {
            "dataco_delivery_risk": {
                "task": "Binary classification: On-Time vs Late delivery",
                "models_evaluated": ["Logistic Regression", "Random Forest", "XGBoost"],
                "imbalance_strategies_evaluated": ["No Handling", "Class Weight", "SMOTE (train-only)"],
                "best_model": dataco_best,
            },
            "scms_supplier_delay": {
                "task": "Binary classification: On-Time vs Delayed shipment",
                "models_evaluated": ["Logistic Regression", "Random Forest", "XGBoost"],
                "imbalance_strategies_evaluated": ["No Handling", "Class Weight", "SMOTE (train-only)"],
                "best_model": scms_best,
            },
            "m5_demand_forecasting": {
                "task": "Time-series forecasting of daily unit demand",
                "models_evaluated": ["Naive", "Seasonal Naive", "ARIMA", "XGBoost"],
                "split": "Chronological (last 60 days held out per series)",
                "best_model": m5_best,
            },
        },
    }


@router.get("/models/comparison")
def models_comparison():
    return {
        "dataco": _read_json(DATACO_RESULTS / "model_comparison.json", required=False) or [],
        "scms": _read_json(SCMS_RESULTS / "model_comparison.json", required=False) or [],
        "m5": _read_json(M5_RESULTS / "model_comparison.json", required=False) or [],
    }


@router.get("/features")
def features():
    return {
        "dataco": _read_json(DATACO_RESULTS / "features.json", required=False) or [],
        "scms": _read_json(SCMS_RESULTS / "features.json", required=False) or [],
        "m5": _read_json(M5_RESULTS / "features.json", required=False) or [],
    }


@router.get("/justifications")
def justifications():
    return {
        "dataco": _read_json(DATACO_RESULTS / "justifications.json", required=False) or [],
        "scms": _read_json(SCMS_RESULTS / "justifications.json", required=False) or [],
        "m5": _read_json(M5_RESULTS / "justifications.json", required=False) or [],
    }
