from __future__ import annotations

import json
import sys
from functools import lru_cache
from pathlib import Path

import joblib
import pandas as pd
from fastapi import APIRouter, HTTPException

BASE_DIR = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE_DIR))

from app.config import DATACO_RESULTS, DATACO_MODELS
from app.schemas import DataCoPredictRequest, DataCoPredictResponse
from ml.dataco.features import build_model_matrix

router = APIRouter(prefix="/api/dataco", tags=["DataCo - Delivery Risk"])


def _read_json(path: Path):
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"Results not found: {path.name}. Run the training pipeline first.")
    with open(path) as f:
        return json.load(f)


@lru_cache(maxsize=1)
def _load_bundle():
    path = DATACO_MODELS / "best_model.joblib"
    if not path.exists():
        raise HTTPException(status_code=404, detail="DataCo model not trained yet. Run scripts/run_all.py.")
    return joblib.load(path)


@router.get("/results")
def get_results():
    return {
        "best_model": _read_json(DATACO_RESULTS / "best_model.json"),
        "model_comparison": _read_json(DATACO_RESULTS / "model_comparison.json"),
        "all_results": _read_json(DATACO_RESULTS / "all_results.json"),
        "class_distribution": _read_json(DATACO_RESULTS / "class_distribution.json"),
    }


@router.post("/predict", response_model=DataCoPredictResponse)
def predict(req: DataCoPredictRequest):
    bundle = _load_bundle()
    fe = bundle["feature_engineer"]
    scaler = bundle["scaler"]
    feature_columns = bundle["feature_columns"]
    model = bundle["model"]

    order_date = pd.to_datetime(req.order_date) if req.order_date else pd.Timestamp.today()
    order_item_value = round(req.unit_price * req.order_quantity * (1 - req.discount_rate), 2)

    row = pd.DataFrame([{
        "shipping_mode": req.shipping_mode,
        "order_region": req.order_region,
        "product_category": req.product_category,
        "product_weight_kg": req.product_weight_kg,
        "order_quantity": req.order_quantity,
        "unit_price": req.unit_price,
        "discount_rate": req.discount_rate,
        "order_item_value": order_item_value,
        "distance_km": req.distance_km,
        "scheduled_shipping_days": req.scheduled_shipping_days,
        "order_day_of_week": order_date.dayofweek,
        "is_weekend_order": int(order_date.dayofweek >= 5),
    }])

    engineered = fe.transform(row)
    X = build_model_matrix(engineered).reindex(columns=feature_columns, fill_value=0)

    if bundle["uses_scaler"]:
        X = pd.DataFrame(scaler.transform(X), columns=feature_columns)

    pred = int(model.predict(X)[0])
    proba = float(model.predict_proba(X)[0, 1]) if hasattr(model, "predict_proba") else float(pred)

    return DataCoPredictResponse(
        prediction="Late" if pred == 1 else "On-Time",
        late_probability=round(proba, 4),
        model_used=bundle["model_name"],
        imbalance_strategy_used=bundle["imbalance_strategy"],
    )
