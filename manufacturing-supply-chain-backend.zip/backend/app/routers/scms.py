from __future__ import annotations

import json
import sys
from functools import lru_cache
from pathlib import Path

import joblib
import pandas as pd
from fastapi import APIRouter, HTTPException

BASE_DIR = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE_DIR))

from app.config import SCMS_RESULTS, SCMS_MODELS
from app.schemas import SCMSPredictRequest, SCMSPredictResponse
from ml.scms.features import build_model_matrix

router = APIRouter(prefix="/api/scms", tags=["SCMS - Supplier/Shipment Delay"])


def _read_json(path: Path):
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"Results not found: {path.name}. Run the training pipeline first.")
    with open(path) as f:
        return json.load(f)


@lru_cache(maxsize=1)
def _load_bundle():
    path = SCMS_MODELS / "best_model.joblib"
    if not path.exists():
        raise HTTPException(status_code=404, detail="SCMS model not trained yet. Run scripts/run_all.py.")
    return joblib.load(path)


@router.get("/results")
def get_results():
    return {
        "best_model": _read_json(SCMS_RESULTS / "best_model.json"),
        "model_comparison": _read_json(SCMS_RESULTS / "model_comparison.json"),
        "all_results": _read_json(SCMS_RESULTS / "all_results.json"),
        "class_distribution": _read_json(SCMS_RESULTS / "class_distribution.json"),
    }


@router.get("/imbalance")
def get_imbalance_comparison():
    """Dedicated No Handling vs Class Weight vs SMOTE comparison."""
    return _read_json(SCMS_RESULTS / "imbalance_comparison.json")


@router.post("/predict", response_model=SCMSPredictResponse)
def predict(req: SCMSPredictRequest):
    bundle = _load_bundle()
    fe = bundle["feature_engineer"]
    scaler = bundle["scaler"]
    feature_columns = bundle["feature_columns"]
    model = bundle["model"]

    total_cost = round(req.order_quantity * req.unit_cost, 2)

    row = pd.DataFrame([{
        "supplier_name": req.supplier_name,
        "supplier_reliability_score": req.supplier_reliability_score,
        "supplier_past_delay_rate": req.supplier_past_delay_rate,
        "shipment_mode": req.shipment_mode,
        "lead_time_days": req.lead_time_days,
        "typical_lead_time_days": req.typical_lead_time_days,
        "order_quantity": req.order_quantity,
        "unit_cost": req.unit_cost,
        "total_cost": total_cost,
        "destination_region": req.destination_region,
        "distance_km": req.distance_km,
    }])

    engineered = fe.transform(row)
    X = build_model_matrix(engineered).reindex(columns=feature_columns, fill_value=0)

    if bundle["uses_scaler"]:
        X = pd.DataFrame(scaler.transform(X), columns=feature_columns)

    pred = int(model.predict(X)[0])
    proba = float(model.predict_proba(X)[0, 1]) if hasattr(model, "predict_proba") else float(pred)

    return SCMSPredictResponse(
        prediction="Delayed" if pred == 1 else "On-Time",
        delay_probability=round(proba, 4),
        model_used=bundle["model_name"],
        imbalance_strategy_used=bundle["imbalance_strategy"],
    )
