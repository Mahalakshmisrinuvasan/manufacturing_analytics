"""
Shared imbalance-handling strategies used by both DataCo and SCMS.

Three strategies are compared for every model, exactly as required:
  1. none          -> no handling, train on the raw imbalanced data
  2. class_weight   -> pass class_weight='balanced' (or scale_pos_weight for
                       XGBoost) to the estimator itself
  3. smote          -> oversample the minority class with SMOTE, applied
                       ONLY to the training fold (never to test data)
"""
from __future__ import annotations

from imblearn.over_sampling import SMOTE

STRATEGIES = ["none", "class_weight", "smote"]


def apply_smote(X_train, y_train, random_state: int = 42):
    """Apply SMOTE to the training data only. Returns resampled X, y."""
    n_minority = min(y_train.value_counts()) if hasattr(y_train, "value_counts") else None
    # k_neighbors must be < number of minority samples; guard for small folds
    k_neighbors = 5
    if n_minority is not None and n_minority <= k_neighbors:
        k_neighbors = max(1, n_minority - 1)
    smote = SMOTE(random_state=random_state, k_neighbors=k_neighbors)
    X_res, y_res = smote.fit_resample(X_train, y_train)
    return X_res, y_res


def class_distribution(y) -> dict:
    import pandas as pd

    counts = pd.Series(y).value_counts().to_dict()
    total = sum(counts.values())
    return {
        str(k): {"count": int(v), "pct": round(v / total * 100, 2)}
        for k, v in sorted(counts.items())
    }
