"""
Shared evaluation utilities.

All metrics here are computed directly from model predictions on held-out
test data -- nothing is hardcoded. Every training script imports from this
module so that DataCo, SCMS and M5 are scored identically and comparably.
"""
from __future__ import annotations

import time
from typing import Any, Callable

import numpy as np
from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    accuracy_score,
    mean_absolute_error,
    mean_squared_error,
)


def classification_metrics(y_true, y_pred, y_proba=None) -> dict[str, Any]:
    """Compute the required classification metrics for a binary task.

    y_true, y_pred: 0/1 arrays (1 = the "negative outcome" class we care
        about, e.g. Late / Delayed).
    y_proba: predicted probability of class 1, used for ROC-AUC.
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()

    metrics = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "confusion_matrix": {
            "true_negative": int(tn),
            "false_positive": int(fp),
            "false_negative": int(fn),
            "true_positive": int(tp),
            "labels": ["0 = On-Time", "1 = Late/Delayed"],
        },
    }

    if y_proba is not None:
        try:
            metrics["roc_auc"] = float(roc_auc_score(y_true, y_proba))
        except ValueError:
            # happens if y_true has only one class present (shouldn't in
            # our stratified splits, but guard anyway)
            metrics["roc_auc"] = None
    else:
        metrics["roc_auc"] = None

    return metrics


def regression_metrics(y_true, y_pred) -> dict[str, Any]:
    """MAE, RMSE, MAPE for forecasting tasks."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)

    mae = float(mean_absolute_error(y_true, y_pred))
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))

    # MAPE, guarding against division by zero on days with zero demand
    denom = np.where(y_true == 0, np.nan, y_true)
    ape = np.abs((y_true - y_pred) / denom) * 100
    mape = float(np.nanmean(ape))

    return {"mae": mae, "rmse": rmse, "mape": mape}


def timed_fit_predict(
    model,
    X_train,
    y_train,
    X_test,
    predict_proba: bool = True,
) -> dict[str, Any]:
    """Fit a model, time training + inference, and return predictions.

    Returns dict with keys: model, y_pred, y_proba, train_time_sec,
    inference_time_sec (for the whole test set) and
    inference_time_ms_per_row.
    """
    t0 = time.perf_counter()
    model.fit(X_train, y_train)
    train_time = time.perf_counter() - t0

    t0 = time.perf_counter()
    y_pred = model.predict(X_test)
    infer_time = time.perf_counter() - t0

    y_proba = None
    if predict_proba and hasattr(model, "predict_proba"):
        y_proba = model.predict_proba(X_test)[:, 1]

    n_rows = len(X_test)
    return {
        "model": model,
        "y_pred": y_pred,
        "y_proba": y_proba,
        "train_time_sec": round(train_time, 4),
        "inference_time_sec": round(infer_time, 4),
        "inference_time_ms_per_row": round((infer_time / n_rows) * 1000, 5) if n_rows else None,
    }
