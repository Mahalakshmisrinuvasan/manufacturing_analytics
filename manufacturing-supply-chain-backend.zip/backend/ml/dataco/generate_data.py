"""
Synthetic DataCo-style Delivery Risk dataset generator.

Generates order-level shipping records with a latent, noisy risk function
that determines whether an order arrives On-Time (0) or Late (1). The risk
function is intentionally realistic: slower shipping modes, longer
distances, high-discount/rush orders, weekend dispatch, and certain
high-risk regions increase the probability of a late delivery, but the
outcome is never a deterministic function of any single column -- there is
always noise, so models have real signal to find but cannot reach 100%.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from pathlib import Path

RANDOM_STATE = 42
N_ROWS = 8000

SHIPPING_MODES = {
    # mode: (scheduled_days, base_late_risk)
    "Same Day": (1, 0.35),
    "First Class": (2, 0.22),
    "Second Class": (4, 0.14),
    "Standard Class": (6, 0.08),
}
REGIONS = {
    # region: (avg_distance_km, region_risk_multiplier)
    "North America": (1200, 1.0),
    "Europe": (900, 1.05),
    "LATAM": (2600, 1.35),
    "APAC": (4200, 1.5),
    "Africa": (3800, 1.6),
}
PRODUCT_CATEGORIES = {
    # category: (avg_weight_kg, avg_unit_price)
    "Electronics": (2.5, 220),
    "Furniture": (28.0, 340),
    "Apparel": (0.6, 45),
    "Office Supplies": (1.8, 35),
    "Sporting Goods": (4.0, 90),
}


def generate_dataco(n_rows: int = N_ROWS, random_state: int = RANDOM_STATE) -> pd.DataFrame:
    rng = np.random.default_rng(random_state)

    shipping_modes = rng.choice(list(SHIPPING_MODES.keys()), size=n_rows,
                                 p=[0.08, 0.22, 0.30, 0.40])
    regions = rng.choice(list(REGIONS.keys()), size=n_rows,
                          p=[0.38, 0.27, 0.15, 0.13, 0.07])
    categories = rng.choice(list(PRODUCT_CATEGORIES.keys()), size=n_rows,
                             p=[0.30, 0.12, 0.24, 0.22, 0.12])

    order_dates = pd.to_datetime("2023-01-01") + pd.to_timedelta(
        rng.integers(0, 730, size=n_rows), unit="D"
    )

    scheduled_days = np.array([SHIPPING_MODES[m][0] for m in shipping_modes])
    mode_risk = np.array([SHIPPING_MODES[m][1] for m in shipping_modes])
    region_mult = np.array([REGIONS[r][1] for r in regions])
    avg_distance = np.array([REGIONS[r][0] for r in regions])
    distance_km = np.clip(rng.normal(avg_distance, avg_distance * 0.25), 50, None)

    avg_weight = np.array([PRODUCT_CATEGORIES[c][0] for c in categories])
    avg_price = np.array([PRODUCT_CATEGORIES[c][1] for c in categories])
    product_weight_kg = np.clip(rng.normal(avg_weight, avg_weight * 0.3 + 0.1), 0.05, None)
    unit_price = np.clip(rng.normal(avg_price, avg_price * 0.2), 5, None)

    order_quantity = rng.integers(1, 12, size=n_rows)
    discount_rate = np.clip(rng.beta(2, 8, size=n_rows), 0, 0.6)
    order_item_value = np.round(unit_price * order_quantity * (1 - discount_rate), 2)

    order_dow = order_dates.dayofweek.values
    is_weekend = (order_dow >= 5).astype(int)

    # ---- latent risk function (drives the label; never exposed to models) ----
    distance_risk = np.clip(distance_km / 6000, 0, 1)
    discount_risk = discount_rate * 0.4          # rushed / deprioritized discount orders
    weekend_risk = is_weekend * 0.06              # weekend dispatch, fewer staff
    qty_risk = np.clip((order_quantity - 1) / 11, 0, 1) * 0.10  # bulk orders harder to consolidate
    weight_risk = np.clip(product_weight_kg / 60, 0, 1) * 0.08

    logit_base = (
        -4.0
        + 5.2 * mode_risk
        + 2.6 * distance_risk * region_mult
        + discount_risk
        + weekend_risk
        + qty_risk
        + weight_risk
    )
    noise = rng.normal(0, 0.35, size=n_rows)
    prob_late = 1 / (1 + np.exp(-(logit_base + noise)))
    is_late = (rng.uniform(0, 1, size=n_rows) < prob_late).astype(int)

    df = pd.DataFrame({
        "order_id": np.arange(1, n_rows + 1),
        "order_date": order_dates,
        "shipping_mode": shipping_modes,
        "order_region": regions,
        "product_category": categories,
        "product_weight_kg": np.round(product_weight_kg, 3),
        "order_quantity": order_quantity,
        "unit_price": np.round(unit_price, 2),
        "discount_rate": np.round(discount_rate, 4),
        "order_item_value": order_item_value,
        "distance_km": np.round(distance_km, 1),
        "scheduled_shipping_days": scheduled_days,
        "order_day_of_week": order_dow,
        "is_weekend_order": is_weekend,
        "delivery_status": np.where(is_late == 1, "Late", "On-Time"),
        "late_delivery_risk": is_late,  # target: 1 = Late, 0 = On-Time
    })
    return df


def main():
    df = generate_dataco()
    out_dir = Path(__file__).resolve().parents[2] / "data" / "dataco"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "raw.csv"
    df.to_csv(out_path, index=False)
    print(f"Wrote {len(df)} rows to {out_path}")
    print(df["delivery_status"].value_counts(normalize=True))


if __name__ == "__main__":
    main()
