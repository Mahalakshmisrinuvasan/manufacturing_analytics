"""
Domain feature engineering for the DataCo Delivery Risk dataset.

Every engineered feature is documented in FEATURE_STORE with its formula,
business meaning, and the reason it was created. This is surfaced verbatim
by GET /api/features -- nothing here is fabricated after the fact, it is
the actual logic used to build the training matrix below.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

TARGET = "late_delivery_risk"

CATEGORICAL_COLS = ["shipping_mode", "order_region", "product_category"]
NUMERIC_COLS = [
    "product_weight_kg", "order_quantity", "unit_price", "discount_rate",
    "order_item_value", "distance_km", "scheduled_shipping_days",
    "order_day_of_week", "is_weekend_order",
]
ENGINEERED_NUMERIC_COLS = [
    "order_density", "value_per_km", "weight_per_unit",
    "schedule_pressure_ratio", "high_discount_flag",
]
TARGET_ENCODED_COLS = ["shipping_mode_risk_encoded", "region_risk_encoded"]

FEATURE_STORE = [
    {
        "name": "product_weight_kg", "domain": "dataco", "type": "raw",
        "formula": "as recorded on the order line",
        "business_meaning": "Heavier shipments are harder to consolidate and route, and are more exposed to carrier capacity constraints.",
        "reason": "Direct proxy for handling complexity; included as a base predictor for all three models.",
    },
    {
        "name": "order_quantity", "domain": "dataco", "type": "raw",
        "formula": "units ordered on the line item",
        "business_meaning": "Bulk orders are more likely to be split across shipments or wait for full-pallet consolidation.",
        "reason": "Operationally, larger orders take longer to pick/pack, which is a known driver of late shipment.",
    },
    {
        "name": "discount_rate", "domain": "dataco", "type": "raw",
        "formula": "(list_price - paid_price) / list_price",
        "business_meaning": "Deeply discounted orders (clearance, promo) are often deprioritized in warehouse fulfillment queues.",
        "reason": "Captures a real-world operational bias where full-price orders get fulfillment priority.",
    },
    {
        "name": "distance_km", "domain": "dataco", "type": "raw",
        "formula": "great-circle distance from fulfillment center to delivery region",
        "business_meaning": "Longer shipping distance mechanically increases transit time and exposure to delay events (customs, transfers, weather).",
        "reason": "The single strongest physical driver of delivery risk; required as a base feature.",
    },
    {
        "name": "scheduled_shipping_days", "domain": "dataco", "type": "raw",
        "formula": "carrier SLA days for the chosen shipping_mode",
        "business_meaning": "The promised delivery window; shorter SLAs leave less buffer to absorb any operational friction.",
        "reason": "Establishes the baseline expectation against which lateness is ultimately judged.",
    },
    {
        "name": "is_weekend_order", "domain": "dataco", "type": "raw",
        "formula": "1 if order_day_of_week in {Sat, Sun} else 0",
        "business_meaning": "Weekend orders enter the fulfillment queue with reduced warehouse staffing.",
        "reason": "Encodes a known operational staffing pattern that raw order_date does not expose to tree models directly.",
    },
    {
        "name": "order_density", "domain": "dataco", "type": "engineered",
        "formula": "order_quantity / (distance_km + 1)",
        "business_meaning": "How many units are being pushed per km of transit -- a proxy for shipment consolidation efficiency.",
        "reason": "Distance and quantity interact (a large order shipped far is riskier than either factor alone); this ratio surfaces that interaction for linear models that can't learn it on their own.",
    },
    {
        "name": "value_per_km", "domain": "dataco", "type": "engineered",
        "formula": "order_item_value / (distance_km + 1)",
        "business_meaning": "Shipment value density; low-value-per-km shipments are more likely to travel on slower, cost-optimized routes.",
        "reason": "Carriers/3PLs commonly route by value-density, which is not explicit in any raw column.",
    },
    {
        "name": "weight_per_unit", "domain": "dataco", "type": "engineered",
        "formula": "product_weight_kg / order_quantity",
        "business_meaning": "Average unit weight; distinguishes bulky-item orders from many-small-item orders even at equal quantity.",
        "reason": "order_quantity and product_weight_kg alone don't capture per-unit bulkiness, which affects packing/handling time.",
    },
    {
        "name": "schedule_pressure_ratio", "domain": "dataco", "type": "engineered",
        "formula": "scheduled_shipping_days / (distance_km / 500 + 1)",
        "business_meaning": "How generous the SLA is relative to distance -- a low ratio flags an SLA that is tight given how far the shipment must travel.",
        "reason": "Directly encodes the domain heuristic 'short SLA + long distance = high risk' as a single interpretable ratio.",
    },
    {
        "name": "high_discount_flag", "domain": "dataco", "type": "engineered",
        "formula": "1 if discount_rate > 0.20 else 0",
        "business_meaning": "Flags orders in the steep-discount tier associated with lowest fulfillment priority.",
        "reason": "A binary threshold feature lets tree models split cleanly on the discount regime shift, rather than fitting the raw continuous rate.",
    },
    {
        "name": "shipping_mode_risk_encoded", "domain": "dataco", "type": "engineered/target-encoded",
        "formula": "smoothed mean(late_delivery_risk) per shipping_mode, computed on TRAIN fold only",
        "business_meaning": "The shipping carrier/service tier's own historical on-time performance.",
        "reason": "Target encoding lets Logistic Regression use the empirical risk of each mode directly as a numeric signal, fit only on training data to avoid leakage.",
    },
    {
        "name": "region_risk_encoded", "domain": "dataco", "type": "engineered/target-encoded",
        "formula": "smoothed mean(late_delivery_risk) per order_region, computed on TRAIN fold only",
        "business_meaning": "Destination region's historical exposure to customs/logistics delay.",
        "reason": "Same rationale as shipping_mode_risk_encoded, applied to geography.",
    },
]


class DataCoFeatureEngineer:
    """Stateful feature engineer: target-encoding statistics are fit on the
    training split only, then applied unchanged to the test split and to
    any future prediction request, to prevent leakage."""

    def __init__(self, smoothing: float = 10.0):
        self.smoothing = smoothing
        self.global_mean_: float | None = None
        self.mode_risk_map_: dict | None = None
        self.region_risk_map_: dict | None = None

    def _smoothed_map(self, df: pd.DataFrame, col: str) -> dict:
        grp = df.groupby(col)[TARGET].agg(["mean", "count"])
        smoothed = (grp["mean"] * grp["count"] + self.global_mean_ * self.smoothing) / (
            grp["count"] + self.smoothing
        )
        return smoothed.to_dict()

    def fit(self, df: pd.DataFrame) -> "DataCoFeatureEngineer":
        self.global_mean_ = float(df[TARGET].mean())
        self.mode_risk_map_ = self._smoothed_map(df, "shipping_mode")
        self.region_risk_map_ = self._smoothed_map(df, "order_region")
        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df["order_density"] = df["order_quantity"] / (df["distance_km"] + 1)
        df["value_per_km"] = df["order_item_value"] / (df["distance_km"] + 1)
        df["weight_per_unit"] = df["product_weight_kg"] / df["order_quantity"].replace(0, 1)
        df["schedule_pressure_ratio"] = df["scheduled_shipping_days"] / (df["distance_km"] / 500 + 1)
        df["high_discount_flag"] = (df["discount_rate"] > 0.20).astype(int)

        df["shipping_mode_risk_encoded"] = df["shipping_mode"].map(self.mode_risk_map_).fillna(self.global_mean_)
        df["region_risk_encoded"] = df["order_region"].map(self.region_risk_map_).fillna(self.global_mean_)
        return df

    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        return self.fit(df).transform(df)


def build_model_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """One-hot encode categoricals + assemble the full numeric matrix used
    directly by scikit-learn / XGBoost."""
    dummies = pd.get_dummies(df[CATEGORICAL_COLS], prefix=CATEGORICAL_COLS)
    numeric = df[NUMERIC_COLS + ENGINEERED_NUMERIC_COLS + TARGET_ENCODED_COLS]
    X = pd.concat([numeric.reset_index(drop=True), dummies.reset_index(drop=True)], axis=1)
    return X


def get_feature_metadata() -> list[dict]:
    return FEATURE_STORE
