"""
Domain feature engineering for the SCMS Supplier/Shipment Delay dataset.

Every engineered feature is documented in FEATURE_STORE with its formula,
business meaning, and the reason it was created (surfaced by
GET /api/features).
"""
from __future__ import annotations

import pandas as pd

TARGET = "shipment_delay"

CATEGORICAL_COLS = ["shipment_mode", "destination_region"]
NUMERIC_COLS = [
    "supplier_reliability_score", "supplier_past_delay_rate", "lead_time_days",
    "typical_lead_time_days", "order_quantity", "unit_cost", "total_cost",
    "distance_km",
]
ENGINEERED_NUMERIC_COLS = [
    "quantity_to_leadtime_ratio", "lead_time_deviation_pct", "cost_per_km",
    "capacity_pressure_flag", "reliability_gap",
]
TARGET_ENCODED_COLS = ["supplier_risk_encoded", "destination_risk_encoded"]

FEATURE_STORE = [
    {
        "name": "supplier_reliability_score", "domain": "scms", "type": "raw",
        "formula": "rolling on-time delivery rate for the supplier over their recent shipment history",
        "business_meaning": "How consistently a supplier has met delivery commitments in the past.",
        "reason": "Strongest prior signal available -- past supplier performance is the classic predictor of future delay risk in procurement analytics.",
    },
    {
        "name": "supplier_past_delay_rate", "domain": "scms", "type": "raw",
        "formula": "1 - supplier_reliability_score (observed historical rate, independently measured)",
        "business_meaning": "Direct historical delay frequency for the supplier.",
        "reason": "Included alongside reliability_score as an independently-measured (noisy) statistic so models see two correlated but not identical views of supplier risk.",
    },
    {
        "name": "lead_time_days", "domain": "scms", "type": "raw",
        "formula": "quoted/actual lead time for this shipment in days",
        "business_meaning": "The time budget for the shipment to arrive; tighter lead times reduce buffer against disruption.",
        "reason": "Core operational feature -- lead time pressure is a primary lever procurement teams can control.",
    },
    {
        "name": "shipment_mode", "domain": "scms", "type": "raw",
        "formula": "carrier mode: Air / Air Charter / Ocean / Truck",
        "business_meaning": "Different modes carry structurally different delay risk (e.g. ocean freight is exposed to port congestion).",
        "reason": "Categorical driver with well-known differing risk profiles across modes; required as a base feature.",
    },
    {
        "name": "order_quantity", "domain": "scms", "type": "raw",
        "formula": "units in the shipment",
        "business_meaning": "Very large orders can strain supplier production/packing capacity and carrier space allocation.",
        "reason": "Order size is a known driver of fulfillment strain in supply chain literature.",
    },
    {
        "name": "total_cost", "domain": "scms", "type": "raw",
        "formula": "order_quantity * unit_cost",
        "business_meaning": "Total shipment value; high-value shipments may get expedited handling or, conversely, extra customs scrutiny.",
        "reason": "Value is a distinct signal from quantity alone (e.g. small quantity of expensive goods vs. bulk of cheap goods).",
    },
    {
        "name": "distance_km", "domain": "scms", "type": "raw",
        "formula": "shipping distance from supplier origin to destination",
        "business_meaning": "Longer distances mean more transit legs and more opportunities for delay.",
        "reason": "Physical driver of transit-time variance, analogous to DataCo's distance feature.",
    },
    {
        "name": "quantity_to_leadtime_ratio", "domain": "scms", "type": "engineered",
        "formula": "order_quantity / lead_time_days",
        "business_meaning": "Throughput pressure -- how many units must move per day of lead time; a high ratio signals an aggressive fulfillment pace.",
        "reason": "Quantity alone doesn't capture urgency; normalizing by lead time surfaces shipments under real scheduling strain.",
    },
    {
        "name": "lead_time_deviation_pct", "domain": "scms", "type": "engineered",
        "formula": "(lead_time_days - typical_lead_time_days) / typical_lead_time_days * 100",
        "business_meaning": "How far the quoted lead time deviates from the shipment mode's normal lead time -- large positive deviation often signals a known disruption already priced into the schedule.",
        "reason": "Raw lead_time_days is not comparable across modes (5 days is fast for Air, impossible for Ocean); this normalizes it.",
    },
    {
        "name": "cost_per_km", "domain": "scms", "type": "engineered",
        "formula": "total_cost / (distance_km + 1)",
        "business_meaning": "Value density of the shipment per km traveled; low-value-density shipments are more likely deprioritized for expedited routing.",
        "reason": "Mirrors DataCo's value_per_km logic in the supplier/procurement context.",
    },
    {
        "name": "capacity_pressure_flag", "domain": "scms", "type": "engineered",
        "formula": "1 if order_quantity > 15000 else 0",
        "business_meaning": "Flags shipments in the top capacity-strain tier where supplier production lines are most likely to fall behind.",
        "reason": "A binary threshold lets tree models split cleanly on the known high-risk large-order regime.",
    },
    {
        "name": "reliability_gap", "domain": "scms", "type": "engineered",
        "formula": "1 - supplier_reliability_score",
        "business_meaning": "Explicit 'risk' framing of reliability (higher = riskier), matching the direction of the target for more intuitive coefficient signs in linear models.",
        "reason": "Logistic regression coefficients are easier for stakeholders to read when feature direction matches target direction.",
    },
    {
        "name": "supplier_risk_encoded", "domain": "scms", "type": "engineered/target-encoded",
        "formula": "smoothed mean(shipment_delay) per supplier_name, computed on TRAIN fold only",
        "business_meaning": "Empirical historical delay rate specifically for this supplier, distinct from the self-reported reliability_score.",
        "reason": "Captures supplier-specific patterns not fully explained by the numeric reliability score (e.g. specific lanes/products a supplier struggles with).",
    },
    {
        "name": "destination_risk_encoded", "domain": "scms", "type": "engineered/target-encoded",
        "formula": "smoothed mean(shipment_delay) per destination_region, computed on TRAIN fold only",
        "business_meaning": "Empirical historical delay rate for shipments into this destination (customs, infrastructure, last-mile risk).",
        "reason": "Encodes geography-specific delay patterns as a single numeric feature usable by all three model types.",
    },
]


class SCMSFeatureEngineer:
    def __init__(self, smoothing: float = 10.0):
        self.smoothing = smoothing
        self.global_mean_: float | None = None
        self.supplier_risk_map_: dict | None = None
        self.destination_risk_map_: dict | None = None

    def _smoothed_map(self, df: pd.DataFrame, col: str) -> dict:
        grp = df.groupby(col)[TARGET].agg(["mean", "count"])
        smoothed = (grp["mean"] * grp["count"] + self.global_mean_ * self.smoothing) / (
            grp["count"] + self.smoothing
        )
        return smoothed.to_dict()

    def fit(self, df: pd.DataFrame) -> "SCMSFeatureEngineer":
        self.global_mean_ = float(df[TARGET].mean())
        self.supplier_risk_map_ = self._smoothed_map(df, "supplier_name")
        self.destination_risk_map_ = self._smoothed_map(df, "destination_region")
        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df["quantity_to_leadtime_ratio"] = df["order_quantity"] / df["lead_time_days"].replace(0, 1)
        df["lead_time_deviation_pct"] = (
            (df["lead_time_days"] - df["typical_lead_time_days"]) / df["typical_lead_time_days"]
        ) * 100
        df["cost_per_km"] = df["total_cost"] / (df["distance_km"] + 1)
        df["capacity_pressure_flag"] = (df["order_quantity"] > 15000).astype(int)
        df["reliability_gap"] = 1 - df["supplier_reliability_score"]

        df["supplier_risk_encoded"] = df["supplier_name"].map(self.supplier_risk_map_).fillna(self.global_mean_)
        df["destination_risk_encoded"] = df["destination_region"].map(self.destination_risk_map_).fillna(self.global_mean_)
        return df

    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        return self.fit(df).transform(df)


def build_model_matrix(df: pd.DataFrame) -> pd.DataFrame:
    dummies = pd.get_dummies(df[CATEGORICAL_COLS], prefix=CATEGORICAL_COLS)
    numeric = df[NUMERIC_COLS + ENGINEERED_NUMERIC_COLS + TARGET_ENCODED_COLS]
    X = pd.concat([numeric.reset_index(drop=True), dummies.reset_index(drop=True)], axis=1)
    return X


def get_feature_metadata() -> list[dict]:
    return FEATURE_STORE
