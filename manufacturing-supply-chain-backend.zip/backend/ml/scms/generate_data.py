"""
Synthetic SCMS-style Supplier/Shipment Delay dataset generator.

Modeled on supply-chain shipment records (in the spirit of the public
SCMS Global Health Delivery dataset): each row is a shipment from a
supplier to a destination, and the label is whether it arrived Delayed (1)
vs On-Time (0). Risk depends on supplier historical reliability, shipment
mode, lead time pressure, order size/cost, and destination -- with noise.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from pathlib import Path

RANDOM_STATE = 7
N_ROWS = 7000

SUPPLIERS = {
    # supplier: true underlying reliability (0-1, higher = more reliable)
    "Supplier A": 0.93, "Supplier B": 0.88, "Supplier C": 0.80,
    "Supplier D": 0.72, "Supplier E": 0.65, "Supplier F": 0.90,
    "Supplier G": 0.78,
}
SHIPMENT_MODES = {
    # mode: (typical_lead_time_days, base_risk)
    "Air": (5, 0.10), "Air Charter": (3, 0.18), "Ocean": (35, 0.22), "Truck": (10, 0.14),
}
DESTINATIONS = {
    # region: risk multiplier (customs/infrastructure risk)
    "Sub-Saharan Africa": 1.55, "South Asia": 1.30, "Southeast Asia": 1.15,
    "Eastern Europe": 1.05, "Latin America": 1.20, "Middle East": 1.10,
}


def generate_scms(n_rows: int = N_ROWS, random_state: int = RANDOM_STATE) -> pd.DataFrame:
    rng = np.random.default_rng(random_state)

    suppliers = rng.choice(list(SUPPLIERS.keys()), size=n_rows,
                            p=[0.20, 0.18, 0.15, 0.12, 0.10, 0.15, 0.10])
    modes = rng.choice(list(SHIPMENT_MODES.keys()), size=n_rows, p=[0.35, 0.10, 0.30, 0.25])
    destinations = rng.choice(list(DESTINATIONS.keys()), size=n_rows,
                               p=[0.25, 0.22, 0.18, 0.13, 0.14, 0.08])

    supplier_reliability = np.array([SUPPLIERS[s] for s in suppliers])
    # supplier_reliability_score: noisy observed version of the true reliability
    # (as if computed from the last N shipments -- a rolling historical stat)
    supplier_reliability_score = np.clip(
        rng.normal(supplier_reliability, 0.05), 0.3, 0.99
    )
    supplier_past_delay_rate = np.round(1 - supplier_reliability_score + rng.normal(0, 0.03, n_rows), 4)
    supplier_past_delay_rate = np.clip(supplier_past_delay_rate, 0.01, 0.9)

    mode_lead_time = np.array([SHIPMENT_MODES[m][0] for m in modes])
    mode_risk = np.array([SHIPMENT_MODES[m][1] for m in modes])
    lead_time_days = np.clip(rng.normal(mode_lead_time, mode_lead_time * 0.2), 1, None).round(1)

    dest_mult = np.array([DESTINATIONS[d] for d in destinations])
    distance_km = np.clip(rng.normal(6000 * dest_mult, 1200), 300, None).round(0)

    order_quantity = rng.integers(50, 20000, size=n_rows)
    unit_cost = np.round(np.clip(rng.normal(4.5, 3.0, n_rows), 0.1, None), 3)
    total_cost = np.round(order_quantity * unit_cost, 2)

    order_dates = pd.to_datetime("2022-06-01") + pd.to_timedelta(
        rng.integers(0, 900, size=n_rows), unit="D"
    )

    # ---- latent risk function ----
    reliability_risk = (1 - supplier_reliability_score) * 1.8
    mode_risk_component = mode_risk * 2.6
    dest_risk = (dest_mult - 1) * 0.9
    qty_pressure = np.clip((order_quantity - 50) / 19950, 0, 1) * 0.35  # very large orders strain capacity
    lead_time_pressure = np.clip((mode_lead_time - lead_time_days) / mode_lead_time, -1, 1) * 0.4
    # negative lead_time_pressure (actual lead time far exceeds typical) raises risk

    logit_base = (
        -4.5
        + 2.6 * reliability_risk
        + 3.6 * mode_risk_component
        + 1.6 * dest_risk
        + qty_pressure
        - lead_time_pressure
    )
    noise = rng.normal(0, 0.4, size=n_rows)
    prob_delay = 1 / (1 + np.exp(-(logit_base + noise)))
    is_delayed = (rng.uniform(0, 1, size=n_rows) < prob_delay).astype(int)

    df = pd.DataFrame({
        "shipment_id": np.arange(1, n_rows + 1),
        "order_date": order_dates,
        "supplier_name": suppliers,
        "supplier_reliability_score": np.round(supplier_reliability_score, 4),
        "supplier_past_delay_rate": supplier_past_delay_rate,
        "shipment_mode": modes,
        "lead_time_days": lead_time_days,
        "typical_lead_time_days": mode_lead_time,
        "order_quantity": order_quantity,
        "unit_cost": unit_cost,
        "total_cost": total_cost,
        "destination_region": destinations,
        "distance_km": distance_km,
        "shipment_status": np.where(is_delayed == 1, "Delayed", "On-Time"),
        "shipment_delay": is_delayed,  # target: 1 = Delayed, 0 = On-Time
    })
    return df


def main():
    df = generate_scms()
    out_dir = Path(__file__).resolve().parents[2] / "data" / "scms"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "raw.csv"
    df.to_csv(out_path, index=False)
    print(f"Wrote {len(df)} rows to {out_path}")
    print(df["shipment_status"].value_counts(normalize=True))


if __name__ == "__main__":
    main()
