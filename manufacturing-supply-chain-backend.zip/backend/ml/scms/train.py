"""
SCMS Supplier/Shipment Delay -- full pipeline (mirrors DataCo):

Synthetic Data -> Preprocessing -> Domain Feature Engineering ->
Train/Test Split -> Multiple Models x Imbalance Strategies -> Evaluation ->
Model Comparison -> Best Model Selection -> Persist (joblib + JSON/CSV)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

BASE_DIR = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE_DIR))

from ml.scms.features import SCMSFeatureEngineer, build_model_matrix, TARGET, get_feature_metadata
from ml.common.evaluation import classification_metrics, timed_fit_predict
from ml.common.imbalance import apply_smote, class_distribution, STRATEGIES

DATA_PATH = BASE_DIR / "data" / "scms" / "raw.csv"
MODEL_DIR = BASE_DIR / "models" / "scms"
RESULTS_DIR = BASE_DIR / "results" / "scms"
RANDOM_STATE = 7

MODEL_QUALITATIVE = {
    "logistic_regression": {
        "interpretability": "High -- coefficients map directly to log-odds of delay per feature, easy to explain to procurement stakeholders.",
        "strengths": ["Fast to train and score", "Coefficients are directly explainable to non-technical stakeholders", "Stable, low variance", "Good baseline for regulatory/audit contexts"],
        "limitations": ["Cannot capture non-linear interactions (e.g. supplier reliability x quantity pressure) without manual engineering", "Sensitive to feature scaling", "Underfits complex risk surfaces"],
    },
    "random_forest": {
        "interpretability": "Medium -- feature importances available, individual trees not human-readable.",
        "strengths": ["Captures non-linear interactions automatically", "Robust to unscaled/mixed features", "Resistant to overfitting relative to a single tree", "Handles categorical one-hot features well"],
        "limitations": ["Larger artifact, slower inference than logistic regression", "Probability calibration less precise out-of-the-box", "Can overfit synthetic minority samples from SMOTE"],
    },
    "xgboost": {
        "interpretability": "Medium -- SHAP/feature importance available, ensemble itself is a black box.",
        "strengths": ["Typically strongest raw predictive performance on tabular data", "Native imbalance handling via scale_pos_weight", "Regularized, reduces overfitting vs plain boosting", "Efficient at scale"],
        "limitations": ["More hyperparameters to tune", "Higher overfitting risk on noisy data without care", "Heavier inference cost than logistic regression"],
    },
}


def build_estimator(model_name: str, strategy: str, y_train: pd.Series):
    use_class_weight = strategy == "class_weight"
    if model_name == "logistic_regression":
        return LogisticRegression(
            max_iter=2000,
            class_weight="balanced" if use_class_weight else None,
            random_state=RANDOM_STATE,
        )
    if model_name == "random_forest":
        return RandomForestClassifier(
            n_estimators=300, max_depth=10, min_samples_leaf=3,
            class_weight="balanced" if use_class_weight else None,
            random_state=RANDOM_STATE, n_jobs=-1,
        )
    if model_name == "xgboost":
        scale_pos_weight = 1.0
        if use_class_weight:
            n_pos = int(y_train.sum())
            n_neg = int(len(y_train) - n_pos)
            scale_pos_weight = n_neg / max(n_pos, 1)
        return XGBClassifier(
            n_estimators=300, max_depth=5, learning_rate=0.08,
            subsample=0.9, colsample_bytree=0.9,
            scale_pos_weight=scale_pos_weight, eval_metric="logloss",
            random_state=RANDOM_STATE, n_jobs=-1,
        )
    raise ValueError(model_name)


def run_pipeline():
    print("[SCMS] Loading synthetic data ...")
    if not DATA_PATH.exists():
        from ml.scms.generate_data import main as gen_main
        gen_main()
    df = pd.read_csv(DATA_PATH, parse_dates=["order_date"])

    print("[SCMS] Preprocessing + train/test split (stratified, 80/20) ...")
    train_df, test_df = train_test_split(
        df, test_size=0.2, random_state=RANDOM_STATE, stratify=df[TARGET]
    )

    print("[SCMS] Domain feature engineering (fit on train only) ...")
    fe = SCMSFeatureEngineer(smoothing=10.0).fit(train_df)
    train_fe = fe.transform(train_df)
    test_fe = fe.transform(test_df)

    X_train_full = build_model_matrix(train_fe)
    X_test_full = build_model_matrix(test_fe).reindex(columns=X_train_full.columns, fill_value=0)
    y_train = train_fe[TARGET].reset_index(drop=True)
    y_test = test_fe[TARGET].reset_index(drop=True)
    feature_columns = list(X_train_full.columns)

    scaler = StandardScaler().fit(X_train_full)
    X_train_scaled = pd.DataFrame(scaler.transform(X_train_full), columns=feature_columns)
    X_test_scaled = pd.DataFrame(scaler.transform(X_test_full), columns=feature_columns)

    train_dist = class_distribution(y_train)
    test_dist = class_distribution(y_test)
    print(f"[SCMS] Train class distribution: {train_dist}")
    print(f"[SCMS] Test class distribution:  {test_dist}")

    all_results = []
    models_to_run = ["logistic_regression", "random_forest", "xgboost"]

    for strategy in STRATEGIES:
        for model_name in models_to_run:
            Xtr_raw = X_train_scaled if model_name == "logistic_regression" else X_train_full
            Xte = X_test_scaled if model_name == "logistic_regression" else X_test_full
            ytr = y_train

            if strategy == "smote":
                Xtr, ytr_used = apply_smote(Xtr_raw, ytr, random_state=RANDOM_STATE)
            else:
                Xtr, ytr_used = Xtr_raw, ytr

            estimator = build_estimator(model_name, strategy, ytr_used)
            fit_result = timed_fit_predict(estimator, Xtr, ytr_used, Xte)
            metrics = classification_metrics(y_test, fit_result["y_pred"], fit_result["y_proba"])

            entry = {
                "model": model_name,
                "imbalance_strategy": strategy,
                "metrics": metrics,
                "train_time_sec": fit_result["train_time_sec"],
                "inference_time_sec": fit_result["inference_time_sec"],
                "inference_time_ms_per_row": fit_result["inference_time_ms_per_row"],
                "train_rows_used": int(len(Xtr)),
            }
            all_results.append(entry)
            print(f"[SCMS] {model_name:20s} | {strategy:13s} | "
                  f"F1={metrics['f1']:.3f} ROC-AUC={metrics['roc_auc']:.3f} "
                  f"Recall={metrics['recall']:.3f}")

    comparison_rows = []
    for r in all_results:
        comparison_rows.append({
            "model": r["model"],
            "imbalance_strategy": r["imbalance_strategy"],
            "precision": r["metrics"]["precision"],
            "recall": r["metrics"]["recall"],
            "f1": r["metrics"]["f1"],
            "roc_auc": r["metrics"]["roc_auc"],
            "accuracy": r["metrics"]["accuracy"],
            "train_time_sec": r["train_time_sec"],
            "inference_time_ms_per_row": r["inference_time_ms_per_row"],
        })
    comparison_df = pd.DataFrame(comparison_rows).sort_values(
        ["f1", "roc_auc"], ascending=False
    ).reset_index(drop=True)

    best_per_model = {}
    for model_name in models_to_run:
        sub = comparison_df[comparison_df.model == model_name].sort_values(
            ["f1", "roc_auc"], ascending=False
        )
        best_per_model[model_name] = sub.iloc[0].to_dict()

    overall_best_row = comparison_df.iloc[0].to_dict()
    overall_best_model_name = overall_best_row["model"]
    overall_best_strategy = overall_best_row["imbalance_strategy"]

    print(f"[SCMS] Overall best: {overall_best_model_name} + {overall_best_strategy} "
          f"(ROC-AUC={overall_best_row['roc_auc']:.3f}, F1={overall_best_row['f1']:.3f})")

    Xtr_raw = X_train_scaled if overall_best_model_name == "logistic_regression" else X_train_full
    if overall_best_strategy == "smote":
        Xtr_final, ytr_final = apply_smote(Xtr_raw, y_train, random_state=RANDOM_STATE)
    else:
        Xtr_final, ytr_final = Xtr_raw, y_train
    final_estimator = build_estimator(overall_best_model_name, overall_best_strategy, ytr_final)
    final_estimator.fit(Xtr_final, ytr_final)

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    bundle = {
        "model": final_estimator,
        "feature_engineer": fe,
        "feature_columns": feature_columns,
        "scaler": scaler,
        "uses_scaler": overall_best_model_name == "logistic_regression",
        "model_name": overall_best_model_name,
        "imbalance_strategy": overall_best_strategy,
    }
    joblib.dump(bundle, MODEL_DIR / "best_model.joblib")

    for model_name in models_to_run:
        strat = best_per_model[model_name]["imbalance_strategy"]
        Xtr_raw_m = X_train_scaled if model_name == "logistic_regression" else X_train_full
        if strat == "smote":
            Xtr_m, ytr_m = apply_smote(Xtr_raw_m, y_train, random_state=RANDOM_STATE)
        else:
            Xtr_m, ytr_m = Xtr_raw_m, y_train
        est = build_estimator(model_name, strat, ytr_m)
        est.fit(Xtr_m, ytr_m)
        joblib.dump(est, MODEL_DIR / f"{model_name}.joblib")

    justifications = []
    for model_name in models_to_run:
        best = best_per_model[model_name]
        selected = model_name == overall_best_model_name
        reason = (
            f"Selected as the production model: across all imbalance strategies, "
            f"{model_name} + {best['imbalance_strategy']} achieved the highest F1 "
            f"({best['f1']:.3f}, ROC-AUC {best['roc_auc']:.3f}) of any combination tested, "
            f"with recall of {best['recall']:.3f} on delayed shipments -- the metric that "
            f"matters most for proactively escalating at-risk supplier shipments."
            if selected else
            f"Rejected in favor of {overall_best_model_name}: its best configuration "
            f"({best['imbalance_strategy']}) reached F1 {best['f1']:.3f} / "
            f"ROC-AUC {best['roc_auc']:.3f}, versus F1 {overall_best_row['f1']:.3f} / "
            f"ROC-AUC {overall_best_row['roc_auc']:.3f} for {overall_best_model_name}."
        )
        justifications.append({
            "model": model_name,
            "best_imbalance_strategy": best["imbalance_strategy"],
            "metrics": {k: best[k] for k in ["precision", "recall", "f1", "roc_auc", "accuracy"]},
            "train_time_sec": best["train_time_sec"],
            "inference_time_ms_per_row": best["inference_time_ms_per_row"],
            "interpretability": MODEL_QUALITATIVE[model_name]["interpretability"],
            "strengths": MODEL_QUALITATIVE[model_name]["strengths"],
            "limitations": MODEL_QUALITATIVE[model_name]["limitations"],
            "status": "SELECTED" if selected else "REJECTED",
            "reason": reason,
        })

    # ---- dedicated imbalance-strategy comparison (No Handling vs Class Weight vs SMOTE) ----
    imbalance_summary = (
        comparison_df.groupby("imbalance_strategy")[["precision", "recall", "f1", "roc_auc", "accuracy"]]
        .mean().round(4).reset_index()
        .to_dict(orient="records")
    )
    imbalance_detail = comparison_df.to_dict(orient="records")

    with open(RESULTS_DIR / "all_results.json", "w") as f:
        json.dump(all_results, f, indent=2, default=str)
    comparison_df.to_csv(RESULTS_DIR / "model_comparison.csv", index=False)
    with open(RESULTS_DIR / "model_comparison.json", "w") as f:
        json.dump(comparison_df.to_dict(orient="records"), f, indent=2)
    with open(RESULTS_DIR / "justifications.json", "w") as f:
        json.dump(justifications, f, indent=2, default=str)
    with open(RESULTS_DIR / "best_model.json", "w") as f:
        json.dump({
            "model": overall_best_model_name,
            "imbalance_strategy": overall_best_strategy,
            "metrics": {k: overall_best_row[k] for k in ["precision", "recall", "f1", "roc_auc", "accuracy"]},
        }, f, indent=2)
    with open(RESULTS_DIR / "class_distribution.json", "w") as f:
        json.dump({"train": train_dist, "test": test_dist}, f, indent=2)
    with open(RESULTS_DIR / "features.json", "w") as f:
        json.dump(get_feature_metadata(), f, indent=2)
    with open(RESULTS_DIR / "imbalance_comparison.json", "w") as f:
        json.dump({
            "summary_by_strategy": imbalance_summary,
            "detail_by_model_and_strategy": imbalance_detail,
            "train_class_distribution": train_dist,
            "test_class_distribution": test_dist,
            "note": "SMOTE was applied to the training fold only, never to the held-out test set.",
        }, f, indent=2)

    print("[SCMS] Pipeline complete. Results + models saved.")
    return {"overall_best": overall_best_row, "n_results": len(all_results)}


if __name__ == "__main__":
    run_pipeline()
