"""
Domain feature engineering for the M5 Demand Forecasting dataset.

Every engineered feature is documented in FEATURE_STORE (surfaced by
GET /api/features). Lag/rolling features are computed per (store_id,
item_id) series so no information leaks across series.
"""
from __future__ import annotations

import pandas as pd

TARGET = "units_sold"

LAGS = [1, 7, 14, 28]
ROLLING_WINDOWS = [7, 14, 28]

FEATURE_STORE = [
    {
        "name": "lag_1", "domain": "m5", "type": "engineered",
        "formula": "units_sold shifted by 1 day, within each (store_id, item_id) series",
        "business_meaning": "Yesterday's demand -- the strongest short-term autocorrelation signal in retail sales.",
        "reason": "Day-to-day demand is highly autocorrelated; lag_1 captures the most recent observed state.",
    },
    {
        "name": "lag_7", "domain": "m5", "type": "engineered",
        "formula": "units_sold shifted by 7 days",
        "business_meaning": "Demand on the same weekday last week -- captures weekly shopping-pattern seasonality (e.g. weekend spikes).",
        "reason": "Retail demand has strong weekly periodicity; a 7-day lag directly encodes 'same day last week'.",
    },
    {
        "name": "lag_14", "domain": "m5", "type": "engineered",
        "formula": "units_sold shifted by 14 days",
        "business_meaning": "Demand two weeks prior -- smooths single-week anomalies while still capturing weekday alignment.",
        "reason": "Provides a second weekly-aligned reference point, useful when last week was itself an outlier (promo, holiday).",
    },
    {
        "name": "lag_28", "domain": "m5", "type": "engineered",
        "formula": "units_sold shifted by 28 days",
        "business_meaning": "Demand four weeks prior -- approximates a monthly-cycle comparison (e.g. paycheck/benefits timing).",
        "reason": "Captures longer-cycle purchasing patterns (e.g. SNAP/benefit disbursement dates) that weekly lags miss.",
    },
    {
        "name": "rolling_mean_7", "domain": "m5", "type": "engineered",
        "formula": "mean(units_sold) over the trailing 7 days (shifted by 1 to avoid leakage)",
        "business_meaning": "Smoothed recent demand level, filtering day-to-day noise.",
        "reason": "A single lag is noisy; a rolling mean gives models a stable estimate of 'current demand level'.",
    },
    {
        "name": "rolling_mean_28", "domain": "m5", "type": "engineered",
        "formula": "mean(units_sold) over the trailing 28 days (shifted by 1 to avoid leakage)",
        "business_meaning": "Longer-horizon demand baseline, used to detect trend shifts relative to the 7-day mean.",
        "reason": "Comparing rolling_mean_7 vs rolling_mean_28 lets models infer whether demand is accelerating or decelerating.",
    },
    {
        "name": "rolling_std_7", "domain": "m5", "type": "engineered",
        "formula": "std(units_sold) over the trailing 7 days (shifted by 1 to avoid leakage)",
        "business_meaning": "Recent demand volatility -- high-variance items need larger safety stock buffers.",
        "reason": "Point forecasts alone don't capture uncertainty; rolling volatility is a leading indicator of forecast risk.",
    },
    {
        "name": "day_of_week", "domain": "m5", "type": "engineered",
        "formula": "calendar day-of-week extracted from date (0=Mon ... 6=Sun)",
        "business_meaning": "Direct encoding of the weekly shopping cycle.",
        "reason": "Lets tree models split cleanly on weekday vs weekend without relying solely on lag features.",
    },
    {
        "name": "month", "domain": "m5", "type": "engineered",
        "formula": "calendar month extracted from date",
        "business_meaning": "Captures broad seasonal/holiday demand patterns across the year.",
        "reason": "Yearly seasonality (e.g. holiday season) is not fully captured by weekly lags alone.",
    },
    {
        "name": "is_weekend", "domain": "m5", "type": "engineered",
        "formula": "1 if day_of_week in {Sat, Sun} else 0",
        "business_meaning": "Explicit weekend flag -- retail foot traffic and basket size differ structurally on weekends.",
        "reason": "A binary flag lets models split on the weekend regime shift directly, complementing the continuous day_of_week feature.",
    },
    {
        "name": "sell_price", "domain": "m5", "type": "raw",
        "formula": "as recorded for the item on that date",
        "business_meaning": "Price is a direct demand driver -- higher price generally suppresses volume (price elasticity).",
        "reason": "Required domain feature: forecasting demand without price ignores a primary controllable driver.",
    },
    {
        "name": "promotion_flag", "domain": "m5", "type": "raw",
        "formula": "1 if the item was on promotion that day else 0",
        "business_meaning": "Promotions cause temporary demand spikes well above the trend/seasonal baseline.",
        "reason": "Without this flag, promo-driven spikes look like unexplained noise to the model, degrading forecast accuracy.",
    },
]


def add_lag_and_rolling_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add lag_*, rolling_mean_*, rolling_std_* features per (store_id, item_id)
    series. Rolling stats are computed on lag_1 (i.e. shifted) so no future
    information leaks into the feature for a given row's date."""
    df = df.sort_values(["store_id", "item_id", "date"]).copy()
    grp = df.groupby(["store_id", "item_id"])[TARGET]

    for lag in LAGS:
        df[f"lag_{lag}"] = grp.shift(lag)

    shifted = grp.shift(1)  # avoid leakage: rolling stats use data up to yesterday
    df["_shifted"] = shifted
    roll_grp = df.groupby(["store_id", "item_id"])["_shifted"]
    df["rolling_mean_7"] = roll_grp.transform(lambda s: s.rolling(7, min_periods=3).mean())
    df["rolling_mean_28"] = roll_grp.transform(lambda s: s.rolling(28, min_periods=7).mean())
    df["rolling_std_7"] = roll_grp.transform(lambda s: s.rolling(7, min_periods=3).std())
    df = df.drop(columns=["_shifted"])
    return df


def add_calendar_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    dt = pd.to_datetime(df["date"])
    df["day_of_week"] = dt.dt.dayofweek
    df["month"] = dt.dt.month
    df["is_weekend"] = (df["day_of_week"] >= 5).astype(int)
    return df


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = add_calendar_features(df)
    df = add_lag_and_rolling_features(df)
    return df


FEATURE_COLUMNS = (
    [f"lag_{l}" for l in LAGS]
    + ["rolling_mean_7", "rolling_mean_28", "rolling_std_7"]
    + ["day_of_week", "month", "is_weekend", "sell_price", "promotion_flag"]
)


def get_feature_metadata() -> list[dict]:
    return FEATURE_STORE
