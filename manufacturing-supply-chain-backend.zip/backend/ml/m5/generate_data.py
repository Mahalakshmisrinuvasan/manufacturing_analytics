"""
Synthetic M5-style Demand Forecasting dataset generator.

Generates daily unit-sales time series for a handful of (store, item)
pairs across ~3 years, with trend, weekly seasonality, yearly seasonality,
price effects, promotions, and noise -- in the spirit of the M5
competition's hierarchical retail demand data.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from pathlib import Path

RANDOM_STATE = 11
N_DAYS = 3 * 365  # ~3 years of daily data
START_DATE = "2021-01-01"

SERIES = [
    # (store_id, item_id, base_level, trend_per_day, weekly_amp, yearly_amp, base_price)
    ("STORE_1", "ITEM_A_FOODS", 60, 0.010, 18, 12, 4.50),
    ("STORE_1", "ITEM_B_HOUSEHOLD", 30, 0.004, 6, 5, 9.20),
    ("STORE_2", "ITEM_A_FOODS", 45, 0.006, 14, 9, 4.75),
    ("STORE_2", "ITEM_C_HOBBIES", 18, -0.002, 4, 8, 15.00),
]


def _series_for(store_id, item_id, base_level, trend_per_day, weekly_amp, yearly_amp,
                 base_price, rng, dates):
    n = len(dates)
    t = np.arange(n)
    dow = dates.dayofweek.values  # 0=Mon .. 6=Sun
    doy = dates.dayofyear.values

    trend = base_level + trend_per_day * t
    weekly = weekly_amp * np.sin(2 * np.pi * (dow / 7) + 1.2) + weekly_amp * 0.4 * (dow >= 5)
    yearly = yearly_amp * np.sin(2 * np.pi * (doy / 365.25) + 0.5)

    # promotions: random ~8% of days, boosts demand
    promo = (rng.uniform(0, 1, size=n) < 0.08).astype(int)
    promo_effect = promo * base_level * 0.35

    # price: small random walk around base_price, promos cut price ~15%
    price_walk = np.cumsum(rng.normal(0, 0.01, size=n))
    sell_price = np.clip(base_price * (1 + price_walk * 0.05), base_price * 0.7, base_price * 1.3)
    sell_price = np.where(promo == 1, sell_price * 0.85, sell_price)
    price_effect = -(sell_price - base_price) * (base_level / base_price) * 0.6

    # snap / calendar event bump (e.g. benefits-payment days -> ~3 days/month)
    snap = ((dates.day.values % 10) == 1).astype(int)
    snap_effect = snap * base_level * 0.08

    mean_demand = np.clip(trend + weekly + yearly + promo_effect + price_effect + snap_effect, 0.5, None)
    noise = rng.normal(0, np.sqrt(mean_demand) * 0.9, size=n)
    units_sold = np.clip(np.round(mean_demand + noise), 0, None)

    return pd.DataFrame({
        "date": dates,
        "store_id": store_id,
        "item_id": item_id,
        "units_sold": units_sold.astype(int),
        "sell_price": np.round(sell_price, 2),
        "promotion_flag": promo,
        "snap_flag": snap,
    })


def generate_m5(n_days: int = N_DAYS, random_state: int = RANDOM_STATE) -> pd.DataFrame:
    rng = np.random.default_rng(random_state)
    dates = pd.date_range(start=START_DATE, periods=n_days, freq="D")

    frames = []
    for store_id, item_id, base_level, trend_per_day, weekly_amp, yearly_amp, base_price in SERIES:
        frames.append(_series_for(store_id, item_id, base_level, trend_per_day,
                                   weekly_amp, yearly_amp, base_price, rng, dates))
    df = pd.concat(frames, ignore_index=True)
    df = df.sort_values(["store_id", "item_id", "date"]).reset_index(drop=True)
    return df


def main():
    df = generate_m5()
    out_dir = Path(__file__).resolve().parents[2] / "data" / "m5"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "raw.csv"
    df.to_csv(out_path, index=False)
    print(f"Wrote {len(df)} rows to {out_path}")
    print(df.groupby(["store_id", "item_id"])["units_sold"].describe())


if __name__ == "__main__":
    main()
